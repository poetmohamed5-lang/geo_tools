import 'package:flutter/material.dart';

import '../crs/crs.dart';
import '../formats/registry.dart';
import '../models/geo.dart';
import '../utils/cp1256.dart';
import '../utils/file_io.dart';

/// قائمة اختيار نظام إحداثيات
class CrsDropdown extends StatelessWidget {
  final CrsDef value;
  final ValueChanged<CrsDef> onChanged;
  final String label;
  final bool enabled;

  const CrsDropdown({super.key, required this.value, required this.onChanged, this.label = 'نظام الإحداثيات', this.enabled = true});

  @override
  Widget build(BuildContext context) {
    final items = [...Crs.all];
    if (!items.contains(value)) items.add(value);
    return LabeledDropdown<CrsDef>(
      value: value,
      label: label,
      items: [for (final c in items) DropdownMenuItem(value: c, child: Text(c.label, overflow: TextOverflow.ellipsis))],
      onChanged: enabled
          ? (v) {
              if (v != null) onChanged(v);
            }
          : null,
    );
  }
}

/// لوحة التصدير: الصيغة + نظام الإحداثيات + خيارات → ملف
class ExportPanel extends StatefulWidget {
  final List<GeoLayer> Function() layers;
  final String baseName;
  const ExportPanel({super.key, required this.layers, required this.baseName});

  @override
  State<ExportPanel> createState() => _ExportPanelState();
}

class _ExportPanelState extends State<ExportPanel> {
  GeoFormat _fmt = GeoFormat.shapefile;
  CrsDef? _target;
  String? _nameField;
  bool _measures = true;
  bool _merge = true;
  TextEnc _dbfEnc = TextEnc.utf8;
  OutFile? _result;
  bool _busy = false;

  @override
  Widget build(BuildContext context) {
    final layers = widget.layers();
    if (layers.isEmpty) return const SizedBox.shrink();
    final srcCrs = layers.first.crs;
    final target = _target ?? srcCrs;
    final fields = <String>{for (final l in layers) ...l.fields}.toList();
    if (_nameField != null && !fields.contains(_nameField)) _nameField = null;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text('حوّل إلى', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Wrap(spacing: 6, runSpacing: 6, children: [
            for (final f in GeoFormat.values)
              ChoiceChip(
                label: Text(f.label),
                selected: _fmt == f,
                onSelected: (_) => setState(() {
                  _fmt = f;
                  _result = null;
                }),
              ),
          ]),
          const SizedBox(height: 12),
          if (_fmt.forcesWgs84)
            const Text('ℹ️ الصيغة دي دايماً بإحداثيات جغرافية WGS84 — التحويل بيتم تلقائي.')
          else
            CrsDropdown(
              label: 'نظام إحداثيات الملف الناتج',
              value: target,
              onChanged: (c) => setState(() {
                _target = c;
                _result = null;
              }),
            ),
          if (_fmt == GeoFormat.dxf && target.geographic)
            const Padding(
              padding: EdgeInsets.only(top: 6),
              child: Text('⚠️ الأوتوكاد بيشتغل بالمتر — يفضّل تختار UTM أو حزام مصري.', style: TextStyle(color: Colors.orange)),
            ),
          if (fields.isNotEmpty && (_fmt == GeoFormat.kml || _fmt == GeoFormat.kmz || _fmt == GeoFormat.dxf || _fmt == GeoFormat.gpx)) ...[
            const SizedBox(height: 12),
            LabeledDropdown<String?>(
              value: _nameField,
              label: _fmt == GeoFormat.dxf ? 'حقل يتكتب كنص على الرسم (اختياري)' : 'حقل اسم العنصر',
              items: [
                DropdownMenuItem<String?>(value: null, child: Text(_fmt == GeoFormat.dxf ? 'بدون نصوص' : 'تلقائي')),
                for (final f in fields) DropdownMenuItem<String?>(value: f, child: Text(f)),
              ],
              onChanged: (v) => setState(() {
                _nameField = v;
                _result = null;
              }),
            ),
          ],
          if (_fmt == GeoFormat.shapefile) ...[
            const SizedBox(height: 12),
            LabeledDropdown<TextEnc>(
              value: _dbfEnc,
              label: 'ترميز النص العربي في DBF',
              items: const [
                DropdownMenuItem(value: TextEnc.utf8, child: Text('UTF-8 (QGIS / ArcGIS Pro)')),
                DropdownMenuItem(value: TextEnc.cp1256, child: Text('Windows-1256 (ArcMap القديم)')),
              ],
              onChanged: (v) => setState(() {
                _dbfEnc = v ?? TextEnc.utf8;
                _result = null;
              }),
            ),
          ],
          if (_fmt == GeoFormat.excel)
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('شيت ملخص بالمساحات (م² + فدان/قيراط/سهم)'),
              value: _measures,
              onChanged: (v) => setState(() {
                _measures = v;
                _result = null;
              }),
            ),
          if (layers.length > 1)
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text('دمج الـ ${layers.length} طبقات في ملف واحد'),
              subtitle: const Text('لو مقفول: كل طبقة ملف لوحدها جوه zip'),
              value: _merge,
              onChanged: (v) => setState(() {
                _merge = v;
                _result = null;
              }),
            ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _busy ? null : () => _run(layers, target),
            icon: _busy
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.play_arrow_rounded),
            label: Text('حوّل إلى ${_fmt.label}'),
          ),
          if (_result != null) ...[const SizedBox(height: 12), OutputActions(file: _result!)],
        ]),
      ),
    );
  }

  Future<void> _run(List<GeoLayer> layers, CrsDef target) async {
    setState(() => _busy = true);
    await Future<void>.delayed(const Duration(milliseconds: 50)); // نسيب الواجهة ترسم المؤشر
    try {
      final opts = WriteOptions(
        targetCrs: target,
        nameField: _nameField,
        addMeasures: _measures,
        dbfEncoding: _dbfEnc,
      );
      final base = safeFileName(widget.baseName);
      final outs = <OutFile>[];
      if (layers.length == 1 || _merge) {
        final l = layers.length == 1 ? layers.first : GeoLayer.merge(layers, base);
        l.name = safeFileName(layers.length == 1 ? l.name : base);
        outs.addAll(writeLayer(l, _fmt, opts));
      } else {
        for (final l in layers) {
          outs.addAll(writeLayer(l, _fmt, opts));
        }
      }
      if (outs.isEmpty) throw Exception('مفيش بيانات تتحول');
      final packed = packOutputs(outs, '${base}_${_fmt.name}');
      setState(() => _result = packed);
    } catch (e) {
      if (mounted) showMsg(context, 'حصل خطأ: $e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }
}

/// كارت ملخص طبقة
class LayerSummaryCard extends StatelessWidget {
  final GeoLayer layer;
  final ValueChanged<CrsDef> onCrsChanged;
  final VoidCallback? onRemove;
  const LayerSummaryCard({super.key, required this.layer, required this.onCrsChanged, this.onRemove});

  @override
  Widget build(BuildContext context) {
    final counts = layer.countByType;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [
            const Icon(Icons.layers_rounded),
            const SizedBox(width: 8),
            Expanded(child: Text(layer.name, style: const TextStyle(fontWeight: FontWeight.bold))),
            if (onRemove != null) IconButton(onPressed: onRemove, icon: const Icon(Icons.close)),
          ]),
          Text([
            for (final e in counts.entries) '${e.value} ${e.key.labelAr}',
            '${layer.fields.length} حقل',
          ].join(' • ')),
          const SizedBox(height: 10),
          CrsDropdown(
            label: layer.crsGuessed ? 'نظام إحداثيات المصدر (متخمن — راجعه)' : 'نظام إحداثيات المصدر',
            value: layer.crs,
            onChanged: onCrsChanged,
          ),
        ]),
      ),
    );
  }
}

/// قائمة منسدلة بعنوان (بديل DropdownButtonFormField بدون APIs متقادمة)
class LabeledDropdown<T> extends StatelessWidget {
  final T value;
  final String label;
  final List<DropdownMenuItem<T>> items;
  final ValueChanged<T?>? onChanged;

  const LabeledDropdown({super.key, required this.value, required this.label, required this.items, this.onChanged});

  @override
  Widget build(BuildContext context) {
    return InputDecorator(
      decoration: InputDecoration(labelText: label, contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4)),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<T>(value: value, isExpanded: true, items: items, onChanged: onChanged),
      ),
    );
  }
}
