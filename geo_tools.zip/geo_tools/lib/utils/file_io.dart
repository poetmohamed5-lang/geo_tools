import 'dart:io';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../models/geo.dart';

/// اختيار ملفات وقراءتها
Future<List<InFile>> pickInputFiles({bool multiple = true}) async {
  final res = await FilePicker.platform.pickFiles(allowMultiple: multiple, withData: true, type: FileType.any);
  if (res == null) return [];
  final out = <InFile>[];
  for (final f in res.files) {
    var bytes = f.bytes;
    if (bytes == null && f.path != null) bytes = await File(f.path!).readAsBytes();
    if (bytes != null) out.add(InFile(f.name, bytes));
  }
  return out;
}

/// حفظ ملف في مكان يختاره المستخدم
Future<String?> saveOutput(OutFile f) async {
  final bytes = f.bytes is Uint8List ? f.bytes as Uint8List : Uint8List.fromList(f.bytes);
  if (Platform.isAndroid || Platform.isIOS) {
    return FilePicker.platform.saveFile(dialogTitle: 'حفظ الملف', fileName: f.name, bytes: bytes);
  }
  final path = await FilePicker.platform.saveFile(dialogTitle: 'حفظ الملف', fileName: f.name);
  if (path == null) return null;
  await File(path).writeAsBytes(bytes);
  return path;
}

/// مشاركة (واتساب، درايف، إيميل…)
Future<void> shareOutput(OutFile f) async {
  final dir = await getTemporaryDirectory();
  final file = File('${dir.path}/${f.name}');
  await file.writeAsBytes(f.bytes, flush: true);
  await Share.shareXFiles([XFile(file.path)]);
}

void showMsg(BuildContext context, String msg, {bool error = false}) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    content: Text(msg),
    backgroundColor: error ? Colors.red.shade700 : null,
  ));
}

/// زرار حفظ + مشاركة لملف ناتج
class OutputActions extends StatelessWidget {
  final OutFile file;
  const OutputActions({super.key, required this.file});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Theme.of(context).colorScheme.secondaryContainer,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(children: [
              const Icon(Icons.check_circle, color: Colors.green),
              const SizedBox(width: 8),
              Expanded(
                child: Text('${file.name}  (${_size(file.bytes.length)})',
                    style: const TextStyle(fontWeight: FontWeight.bold), textDirection: TextDirection.ltr),
              ),
            ]),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: () async {
                    try {
                      final p = await saveOutput(file);
                      if (p != null && context.mounted) showMsg(context, 'اتحفظ ✔');
                    } catch (e) {
                      if (context.mounted) showMsg(context, 'فشل الحفظ: $e', error: true);
                    }
                  },
                  icon: const Icon(Icons.save_alt),
                  label: const Text('حفظ'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => shareOutput(file),
                  icon: const Icon(Icons.share),
                  label: const Text('مشاركة'),
                ),
              ),
            ]),
          ],
        ),
      ),
    );
  }

  static String _size(int b) {
    if (b < 1024) return '$b B';
    if (b < 1024 * 1024) return '${(b / 1024).toStringAsFixed(1)} KB';
    return '${(b / 1024 / 1024).toStringAsFixed(2)} MB';
  }
}
