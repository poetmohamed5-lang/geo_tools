import 'package:geolocator/geolocator.dart';

/// موقع الجهاز الحالي بأعلى دقة (بيطلب الإذن لو محتاج)
Future<Position> getCurrentPosition() async {
  if (!await Geolocator.isLocationServiceEnabled()) {
    throw Exception('شغّل الـ GPS (خدمة الموقع) الأول');
  }
  var perm = await Geolocator.checkPermission();
  if (perm == LocationPermission.denied) {
    perm = await Geolocator.requestPermission();
  }
  if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
    throw Exception('محتاج إذن الوصول للموقع');
  }
  return Geolocator.getCurrentPosition(
    locationSettings: const LocationSettings(accuracy: LocationAccuracy.best, timeLimit: Duration(seconds: 30)),
  );
}
