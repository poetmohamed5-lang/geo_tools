import 'dart:math' as math;

import '../crs/crs.dart';
import '../models/geo.dart';

/// مساحة موقّعة (Shoelace) — موجبة = عكس عقارب الساعة
double signedArea(List<Coord> ring) {
  if (ring.length < 3) return 0;
  var s = 0.0;
  for (var i = 0; i < ring.length; i++) {
    final a = ring[i];
    final b = ring[(i + 1) % ring.length];
    s += a.x * b.y - b.x * a.y;
  }
  return s / 2;
}

bool isClockwise(List<Coord> ring) => signedArea(ring) < 0;

List<Coord> closeRing(List<Coord> ring) {
  if (ring.isEmpty) return ring;
  if (ring.first.sameXY(ring.last)) return ring;
  return [...ring, ring.first];
}

List<Coord> withOrientation(List<Coord> ring, {required bool clockwise}) {
  final r = closeRing(ring);
  return isClockwise(r) == clockwise ? r : r.reversed.toList();
}

bool pointInRing(Coord p, List<Coord> ring) {
  var inside = false;
  for (var i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    final a = ring[i], b = ring[j];
    if (((a.y > p.y) != (b.y > p.y)) && (p.x < (b.x - a.x) * (p.y - a.y) / ((b.y - a.y) == 0 ? 1e-30 : (b.y - a.y)) + a.x)) {
      inside = !inside;
    }
  }
  return inside;
}

/// يجمع الحلقات لمضلعات: [[خارجية, فتحة, فتحة], [خارجية], ...]
List<List<List<Coord>>> groupRings(List<List<Coord>> rings) {
  final valid = rings.where((r) => r.length >= 3).toList();
  // الأكبر الأول عشان الاحتواء يشتغل صح
  valid.sort((a, b) => signedArea(b).abs().compareTo(signedArea(a).abs()));
  final polys = <List<List<Coord>>>[];
  for (final r in valid) {
    List<List<Coord>>? host;
    for (final p in polys) {
      final inOuter = pointInRing(_interiorProbe(r), p.first);
      if (!inOuter) continue;
      // لو جوه فتحة من فتحات المضلع ده يبقى جزيرة جوه الفتحة → مضلع جديد
      final inHole = p.skip(1).any((h) => pointInRing(_interiorProbe(r), h));
      if (!inHole) {
        host = p;
        break;
      }
    }
    if (host != null) {
      host.add(r);
    } else {
      polys.add([r]);
    }
  }
  return polys;
}

Coord _interiorProbe(List<Coord> r) {
  // منتصف أول ضلع بيقلل مشكلة النقاط المشتركة على الحدود
  if (r.length >= 2) {
    return Coord((r[0].x + r[1].x) / 2, (r[0].y + r[1].y) / 2);
  }
  return r.first;
}

double _len(List<Coord> pts) {
  var s = 0.0;
  for (var i = 1; i < pts.length; i++) {
    s += math.sqrt(math.pow(pts[i].x - pts[i - 1].x, 2) + math.pow(pts[i].y - pts[i - 1].y, 2));
  }
  return s;
}

/// قياسات عنصر بالمتر
class Measure {
  final double area; // م²
  final double perimeter; // م
  final double length; // م (للخطوط)
  const Measure(this.area, this.perimeter, this.length);
}

/// بيحسب بالمتر: لو الطبقة جغرافية بيحولها مؤقتاً لـ UTM المناسب
class Measurer {
  final CrsDef crs;
  CrsTransformer? _t;

  Measurer(this.crs, {Coord? sample}) {
    if (crs.geographic) {
      final lon = sample?.x ?? 31.0;
      _t = CrsTransformer(crs, Crs.utmForLon(lon));
    }
  }

  List<Coord> _m(List<Coord> pts) => _t == null ? pts : [for (final p in pts) _t!.apply(p)];

  Measure of(Feature f) {
    if (f.type == GeomType.point) return const Measure(0, 0, 0);
    if (f.type == GeomType.line) {
      var l = 0.0;
      for (final p in f.parts) {
        l += _len(_m(p));
      }
      return Measure(0, 0, l);
    }
    var a = 0.0, per = 0.0;
    for (final poly in groupRings([for (final r in f.parts) _m(r)])) {
      a += signedArea(poly.first).abs();
      for (final h in poly.skip(1)) {
        a -= signedArea(h).abs();
      }
      for (final r in poly) {
        per += _len(closeRing(r));
      }
    }
    return Measure(a, per, 0);
  }
}

/// نقطة تمثيلية (للتسميات في DXF مثلاً)
Coord labelPoint(Feature f) {
  if (f.type == GeomType.polygon && f.parts.isNotEmpty) {
    final r = f.parts.first;
    final a = signedArea(r);
    if (a.abs() > 1e-12) {
      var cx = 0.0, cy = 0.0;
      for (var i = 0; i < r.length; i++) {
        final p = r[i], q = r[(i + 1) % r.length];
        final cr = p.x * q.y - q.x * p.y;
        cx += (p.x + q.x) * cr;
        cy += (p.y + q.y) * cr;
      }
      return Coord(cx / (6 * a), cy / (6 * a));
    }
  }
  if (f.type == GeomType.line && f.parts.isNotEmpty && f.parts.first.isNotEmpty) {
    final p = f.parts.first;
    return p[p.length ~/ 2];
  }
  return f.allCoords.isEmpty ? const Coord(0, 0) : f.allCoords.first;
}

// ───────── وحدات المساحة المصرية ─────────

const double sqmPerFeddan = 4200.8333;
const double sqmPerQirat = sqmPerFeddan / 24;
const double sqmPerSahm = sqmPerQirat / 24;

/// "2 ف  5 ط  12.3 س"
String feddanText(double sqm) {
  // نقرّب لأقرب عُشر سهم الأول عشان أخطاء الكسور العشرية
  final totalSahm = (sqm / sqmPerSahm * 10).round() / 10;
  final f = (totalSahm / 576).floor();
  final rest = totalSahm - f * 576;
  final q = (rest / 24).floor();
  final s = rest - q * 24;
  return '$f ف  $q ط  ${s.toStringAsFixed(1)} س';
}

String fmtNum(double v, [int dec = 2]) {
  final s = v.toStringAsFixed(dec);
  final parts = s.split('.');
  final ip = parts[0].replaceAllMapped(RegExp(r'(\d)(?=(\d{3})+$)'), (m) => '${m[1]},');
  return parts.length > 1 ? '$ip.${parts[1]}' : ip;
}

// ───────── درجات/دقائق/ثواني ─────────

/// يقرأ رقم عادي أو DMS زي: 30°02'45.3"N  أو  30 2 45.3  أو  31:14:10 E
double? parseCoordValue(dynamic v) {
  if (v == null) return null;
  if (v is num) return v.toDouble();
  var s = v.toString().trim();
  if (s.isEmpty) return null;
  // أرقام عربية → إنجليزي
  const ar = '٠١٢٣٤٥٦٧٨٩';
  for (var i = 0; i < 10; i++) {
    s = s.replaceAll(ar[i], '$i');
  }
  s = s.replaceAll('٫', '.').replaceAll('،', ',');
  final direct = double.tryParse(s.replaceAll(',', ''));
  if (direct != null) return direct;

  var sign = 1.0;
  final up = s.toUpperCase();
  if (up.contains('S') || up.contains('W') || up.contains('غ') || up.contains('ج') || s.startsWith('-')) {
    sign = -1.0;
  }
  final nums = RegExp(r'\d+(?:[.,]\d+)?').allMatches(s).map((m) => double.parse(m[0]!.replaceAll(',', '.'))).toList();
  if (nums.isEmpty) return null;
  final d = nums[0];
  final m = nums.length > 1 ? nums[1] : 0.0;
  final sec = nums.length > 2 ? nums[2] : 0.0;
  return sign * (d + m / 60 + sec / 3600);
}

String toDms(double v, {required bool isLat}) {
  final hemi = isLat ? (v >= 0 ? 'N' : 'S') : (v >= 0 ? 'E' : 'W');
  var a = v.abs();
  final d = a.floor();
  a = (a - d) * 60;
  final m = a.floor();
  final s = (a - m) * 60;
  return '$d°${m.toString().padLeft(2, '0')}\'${s.toStringAsFixed(2).padLeft(5, '0')}"$hemi';
}
