import 'package:proj4dart/proj4dart.dart' as p4;

import '../models/geo.dart';

/// تعريف نظام إحداثيات
class CrsDef {
  final String id; // كود داخلي ثابت
  final String nameAr;
  final int? epsg;
  final String proj4;
  final String prjWkt; // صيغة ESRI لملف .prj
  final bool geographic;

  const CrsDef({
    required this.id,
    required this.nameAr,
    required this.proj4,
    required this.prjWkt,
    this.epsg,
    this.geographic = false,
  });

  String get label => epsg == null ? nameAr : '$nameAr (EPSG:$epsg)';

  @override
  bool operator ==(Object other) => other is CrsDef && other.id == id;
  @override
  int get hashCode => id.hashCode;
}

const _gcsWgs84 =
    'GEOGCS["GCS_WGS_1984",DATUM["D_WGS_1984",SPHEROID["WGS_1984",6378137.0,298.257223563]],'
    'PRIMEM["Greenwich",0.0],UNIT["Degree",0.0174532925199433]]';

const _gcsEgypt1907 =
    'GEOGCS["GCS_Egypt_1907",DATUM["D_Egypt_1907",SPHEROID["Helmert_1906",6378200.0,298.3]],'
    'PRIMEM["Greenwich",0.0],UNIT["Degree",0.0174532925199433]]';

String _tmercWkt(String name, String gcs, double fe, double fn, double cm, double k, double lat0) =>
    'PROJCS["$name",$gcs,PROJECTION["Transverse_Mercator"],'
    'PARAMETER["False_Easting",$fe],PARAMETER["False_Northing",$fn],'
    'PARAMETER["Central_Meridian",$cm],PARAMETER["Scale_Factor",$k],'
    'PARAMETER["Latitude_Of_Origin",$lat0],UNIT["Meter",1.0]]';

/// معاملات تحويل داتم مصر 1907 → WGS84 (EPSG:1148، دقة ~4 م).
/// لو عندك معاملات محلية أدق غيّرها هنا.
const egypt1907ToWgs84 = '-130,110,-13,0,0,0,0';

class Crs {
  static const wgs84 = CrsDef(
    id: 'wgs84',
    nameAr: 'جغرافي WGS84 (خط طول/عرض)',
    epsg: 4326,
    proj4: '+proj=longlat +datum=WGS84 +no_defs',
    prjWkt: _gcsWgs84,
    geographic: true,
  );

  static CrsDef _utm(int zone) => CrsDef(
        id: 'utm${zone}n',
        nameAr: 'UTM زون $zone شمال (WGS84)',
        epsg: 32600 + zone,
        proj4: '+proj=utm +zone=$zone +datum=WGS84 +units=m +no_defs',
        prjWkt: _tmercWkt('WGS_1984_UTM_Zone_${zone}N', _gcsWgs84, 500000.0, 0.0,
            (zone * 6 - 183).toDouble(), 0.9996, 0.0),
      );

  static final utm35 = _utm(35);
  static final utm36 = _utm(36);
  static final utm37 = _utm(37);

  static final egRed = CrsDef(
    id: 'eg_red',
    nameAr: 'مصر 1907 — الحزام الأحمر',
    epsg: 22992,
    proj4: '+proj=tmerc +lat_0=30 +lon_0=31 +k=1 +x_0=615000 +y_0=810000 '
        '+a=6378200 +rf=298.3 +towgs84=$egypt1907ToWgs84 +units=m +no_defs',
    prjWkt: _tmercWkt('Egypt_1907_Red_Belt', _gcsEgypt1907, 615000.0, 810000.0, 31.0, 1.0, 30.0),
  );

  static final egPurple = CrsDef(
    id: 'eg_purple',
    nameAr: 'مصر 1907 — الحزام البنفسجي',
    epsg: 22993,
    proj4: '+proj=tmerc +lat_0=30 +lon_0=27 +k=1 +x_0=700000 +y_0=200000 '
        '+a=6378200 +rf=298.3 +towgs84=$egypt1907ToWgs84 +units=m +no_defs',
    prjWkt: _tmercWkt('Egypt_1907_Purple_Belt', _gcsEgypt1907, 700000.0, 200000.0, 27.0, 1.0, 30.0),
  );

  static final egExtPurple = CrsDef(
    id: 'eg_ext_purple',
    nameAr: 'مصر 1907 — البنفسجي الممتد',
    epsg: 22994,
    proj4: '+proj=tmerc +lat_0=30 +lon_0=27 +k=1 +x_0=700000 +y_0=1200000 '
        '+a=6378200 +rf=298.3 +towgs84=$egypt1907ToWgs84 +units=m +no_defs',
    prjWkt: _tmercWkt(
        'Egypt_1907_Extended_Purple_Belt', _gcsEgypt1907, 700000.0, 1200000.0, 27.0, 1.0, 30.0),
  );

  static final egBlue = CrsDef(
    id: 'eg_blue',
    nameAr: 'مصر 1907 — الحزام الأزرق',
    epsg: 22991,
    proj4: '+proj=tmerc +lat_0=30 +lon_0=35 +k=1 +x_0=300000 +y_0=1100000 '
        '+a=6378200 +rf=298.3 +towgs84=$egypt1907ToWgs84 +units=m +no_defs',
    prjWkt: _tmercWkt('Egypt_1907_Blue_Belt', _gcsEgypt1907, 300000.0, 1100000.0, 35.0, 1.0, 30.0),
  );

  static final List<CrsDef> all = [wgs84, utm36, utm35, utm37, egRed, egPurple, egExtPurple, egBlue];

  static CrsDef byId(String id) => all.firstWhere((c) => c.id == id, orElse: () => wgs84);

  static CrsDef? byEpsg(int code) {
    for (final c in all) {
      if (c.epsg == code) return c;
    }
    if (code >= 32601 && code <= 32660) return _utm(code - 32600);
    return null;
  }

  /// UTM مناسب لخط طول معين (لحساب المساحات من إحداثيات جغرافية)
  static CrsDef utmForLon(double lon) {
    final zone = ((lon + 180) / 6).floor() + 1;
    return _utm(zone.clamp(1, 60));
  }

  /// يحاول يتعرف على النظام من محتوى ملف .prj
  static CrsDef? fromPrj(String wkt) {
    final w = wkt.toUpperCase();
    if (!w.contains('PROJCS')) {
      if (w.contains('GEOGCS')) return wgs84; // نعتبر أي جغرافي WGS84 (أو قريب جداً منه)
      return null;
    }
    double? param(String name) {
      final m = RegExp('PARAMETER\\["${name.toUpperCase()}",\\s*(-?[0-9.Ee+-]+)\\]').firstMatch(w);
      return m == null ? null : double.tryParse(m.group(1)!);
    }

    final m = RegExp(r'UTM_ZONE_(\d+)([NS])').firstMatch(w) ?? RegExp(r'UTM ZONE (\d+)([NS])').firstMatch(w);
    if (m != null && m.group(2) == 'N') return _utm(int.parse(m.group(1)!));

    final fe = param('False_Easting');
    final fn = param('False_Northing');
    final cm = param('Central_Meridian');
    if (fe == null || cm == null) return null;
    bool near(double? a, double b) => a != null && (a - b).abs() < 1e-6;

    if (near(fe, 500000) && near(fn ?? 0, 0) && w.contains('0.9996')) {
      final zone = ((cm + 183) / 6).round();
      return _utm(zone);
    }
    if (near(fe, 615000) && near(cm, 31)) return egRed;
    if (near(fe, 700000) && near(fn, 200000) && near(cm, 27)) return egPurple;
    if (near(fe, 700000) && near(fn, 1200000) && near(cm, 27)) return egExtPurple;
    if (near(fe, 300000) && near(cm, 35)) return egBlue;
    return null;
  }

  /// تخمين من قيم الإحداثيات
  static CrsDef guessFromCoords(Iterable<Coord> coords) {
    var n = 0;
    double minX = double.infinity, maxX = -double.infinity, minY = double.infinity, maxY = -double.infinity;
    for (final c in coords) {
      n++;
      if (c.x < minX) minX = c.x;
      if (c.x > maxX) maxX = c.x;
      if (c.y < minY) minY = c.y;
      if (c.y > maxY) maxY = c.y;
      if (n > 5000) break;
    }
    if (n == 0) return wgs84;
    if (minX >= -180 && maxX <= 180 && minY >= -90 && maxY <= 90) return wgs84;
    // UTM في مصر: شماليات تقريباً 2.4 → 3.6 مليون
    if (minY > 2300000 && maxY < 3700000 && minX > 100000 && maxX < 900000) return utm36;
    // الأحزمة المصرية: شماليات أقل من 1.6 مليون
    if (maxY < 1600000) {
      if (minX > 450000 && maxX < 800000 && minY > 500000) return egRed;
      if (minY < 500000 && maxX < 1100000) return egPurple;
      return egRed;
    }
    return utm36;
  }
}

/// مُحوِّل بين نظامين (بيخزن الإسقاطات عشان السرعة)
class CrsTransformer {
  final CrsDef from;
  final CrsDef to;
  late final p4.Projection _src;
  late final p4.Projection _dst;
  final bool identity;

  CrsTransformer(this.from, this.to) : identity = from.id == to.id {
    if (!identity) {
      _src = _proj(from);
      _dst = _proj(to);
    }
  }

  static p4.Projection _proj(CrsDef c) {
    final code = 'GT:${c.id}';
    return p4.Projection.get(code) ?? p4.Projection.add(code, c.proj4);
  }

  Coord apply(Coord c) {
    if (identity) return c;
    final r = _src.transform(_dst, p4.Point(x: c.x, y: c.y));
    return Coord(r.x, r.y, c.z);
  }
}
