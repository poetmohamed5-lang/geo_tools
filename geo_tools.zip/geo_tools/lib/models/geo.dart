import '../crs/crs.dart';

/// نوع الشكل الهندسي
enum GeomType { point, line, polygon }

extension GeomTypeX on GeomType {
  String get key => switch (this) {
        GeomType.point => 'point',
        GeomType.line => 'line',
        GeomType.polygon => 'polygon',
      };

  String get labelAr => switch (this) {
        GeomType.point => 'نقاط',
        GeomType.line => 'خطوط',
        GeomType.polygon => 'مضلعات (قطع)',
      };

  static GeomType? fromKey(String? s) {
    final v = (s ?? '').trim().toLowerCase();
    if (v.startsWith('point') || v == 'نقطة' || v == 'نقاط') return GeomType.point;
    if (v.startsWith('line') || v.startsWith('polyline') || v == 'خط') return GeomType.line;
    if (v.startsWith('polygon') || v == 'مضلع' || v == 'قطعة') return GeomType.polygon;
    return null;
  }
}

/// إحداثي واحد (x = شرقيات/خط طول ، y = شماليات/خط عرض)
class Coord {
  final double x;
  final double y;
  final double? z;
  const Coord(this.x, this.y, [this.z]);

  Coord copyWith({double? x, double? y, double? z}) => Coord(x ?? this.x, y ?? this.y, z ?? this.z);

  bool sameXY(Coord o) => (x - o.x).abs() < 1e-12 && (y - o.y).abs() < 1e-12;

  @override
  String toString() => 'Coord($x, $y${z == null ? '' : ', $z'})';
}

/// عنصر جغرافي: شكل + بيانات وصفية
///
/// [parts]:
///  - نقاط: كل جزء فيه نقطة واحدة (أكتر من جزء = MultiPoint)
///  - خطوط: كل جزء خط مستقل
///  - مضلعات: كل جزء حلقة (خارجية أو فتحة داخلية) — التجميع بيتم بالاحتواء
class Feature {
  GeomType type;
  List<List<Coord>> parts;
  Map<String, dynamic> attrs;

  Feature(this.type, this.parts, [Map<String, dynamic>? attrs]) : attrs = attrs ?? <String, dynamic>{};

  bool get isEmpty => parts.isEmpty || parts.every((p) => p.isEmpty);

  Iterable<Coord> get allCoords sync* {
    for (final p in parts) {
      yield* p;
    }
  }

  Feature mapCoords(Coord Function(Coord) f) =>
      Feature(type, [for (final p in parts) [for (final c in p) f(c)]], Map.of(attrs));
}

/// طبقة = مجموعة عناصر + نظام إحداثيات + ترتيب الحقول
class GeoLayer {
  String name;
  List<Feature> features;
  CrsDef crs;
  List<String> fields;

  /// لو نظام الإحداثيات اتعرف تلقائي ومش مؤكد
  bool crsGuessed;

  GeoLayer({
    required this.name,
    required this.features,
    required this.crs,
    List<String>? fields,
    this.crsGuessed = false,
  }) : fields = fields ?? _collectFields(features);

  static List<String> _collectFields(List<Feature> fs) {
    final seen = <String>{};
    final out = <String>[];
    for (final f in fs) {
      for (final k in f.attrs.keys) {
        if (seen.add(k)) out.add(k);
      }
    }
    return out;
  }

  void refreshFields() {
    final seen = fields.toSet();
    for (final f in features) {
      for (final k in f.attrs.keys) {
        if (seen.add(k)) fields.add(k);
      }
    }
  }

  Map<GeomType, int> get countByType {
    final m = <GeomType, int>{};
    for (final f in features) {
      m[f.type] = (m[f.type] ?? 0) + 1;
    }
    return m;
  }

  /// نسخة محولة لنظام إحداثيات تاني
  GeoLayer transformedTo(CrsDef target) {
    if (target.id == crs.id) return this;
    final t = CrsTransformer(crs, target);
    return GeoLayer(
      name: name,
      features: [for (final f in features) f.mapCoords(t.apply)],
      crs: target,
      fields: List.of(fields),
    );
  }

  /// [minX, minY, maxX, maxY] أو null لو فاضية
  List<double>? get bbox {
    double? a, b, c, d;
    for (final f in features) {
      for (final p in f.allCoords) {
        a = a == null ? p.x : (p.x < a ? p.x : a);
        b = b == null ? p.y : (p.y < b ? p.y : b);
        c = c == null ? p.x : (p.x > c ? p.x : c);
        d = d == null ? p.y : (p.y > d ? p.y : d);
      }
    }
    if (a == null) return null;
    return [a, b!, c!, d!];
  }

  static GeoLayer merge(List<GeoLayer> layers, String name) {
    final target = layers.first.crs;
    final fields = <String>[];
    final seen = <String>{};
    final feats = <Feature>[];
    for (final l in layers) {
      final t = l.transformedTo(target);
      for (final k in t.fields) {
        if (seen.add(k)) fields.add(k);
      }
      if (layers.length > 1 && seen.add('source')) fields.add('source');
      for (final f in t.features) {
        final a = Map<String, dynamic>.of(f.attrs);
        if (layers.length > 1) a['source'] = l.name;
        feats.add(Feature(f.type, f.parts, a));
      }
    }
    return GeoLayer(name: name, features: feats, crs: target, fields: fields);
  }
}

/// ملف ناتج من عملية كتابة
class OutFile {
  final String name;
  final List<int> bytes;
  OutFile(this.name, this.bytes);
}

/// ملف داخل (من file_picker أو من zip)
class InFile {
  final String name;
  final List<int> bytes;
  InFile(this.name, this.bytes);

  String get ext {
    final i = name.lastIndexOf('.');
    return i < 0 ? '' : name.substring(i + 1).toLowerCase();
  }

  String get baseName {
    final slash = name.replaceAll('\\', '/').lastIndexOf('/');
    final n = slash >= 0 ? name.substring(slash + 1) : name;
    final i = n.lastIndexOf('.');
    return i <= 0 ? n : n.substring(0, i);
  }
}
