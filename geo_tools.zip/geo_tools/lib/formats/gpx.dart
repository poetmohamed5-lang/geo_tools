import 'dart:convert';

import 'package:xml/xml.dart';

import '../crs/crs.dart';
import '../models/geo.dart';
import '../utils/geometry.dart';

Iterable<XmlElement> _desc(XmlElement e, String local) =>
    e.descendants.whereType<XmlElement>().where((x) => x.name.local == local);

String? _childText(XmlElement e, String local) {
  for (final c in e.children.whereType<XmlElement>()) {
    if (c.name.local == local) {
      final t = c.innerText.trim();
      return t.isEmpty ? null : t;
    }
  }
  return null;
}

Coord? _pt(XmlElement e) {
  final lat = double.tryParse(e.getAttribute('lat') ?? '');
  final lon = double.tryParse(e.getAttribute('lon') ?? '');
  if (lat == null || lon == null) return null;
  final ele = double.tryParse(_childText(e, 'ele') ?? '');
  return Coord(lon, lat, ele);
}

GeoLayer readGpx(String name, List<int> bytes) {
  final root = XmlDocument.parse(utf8.decode(bytes, allowMalformed: true)).rootElement;
  final feats = <Feature>[];
  for (final w in _desc(root, 'wpt')) {
    final c = _pt(w);
    if (c == null) continue;
    feats.add(Feature(GeomType.point, [
      [c]
    ], {
      'name': _childText(w, 'name'),
      'description': _childText(w, 'desc'),
      'time': _childText(w, 'time'),
    }));
  }
  for (final r in _desc(root, 'rte')) {
    final pts = [for (final p in _desc(r, 'rtept')) _pt(p)].whereType<Coord>().toList();
    if (pts.length >= 2) {
      feats.add(Feature(GeomType.line, [pts], {'name': _childText(r, 'name'), 'description': _childText(r, 'desc')}));
    }
  }
  for (final t in _desc(root, 'trk')) {
    final parts = <List<Coord>>[];
    for (final seg in _desc(t, 'trkseg')) {
      final pts = [for (final p in _desc(seg, 'trkpt')) _pt(p)].whereType<Coord>().toList();
      if (pts.length >= 2) parts.add(pts);
    }
    if (parts.isNotEmpty) {
      feats.add(Feature(GeomType.line, parts, {'name': _childText(t, 'name'), 'description': _childText(t, 'desc')}));
    }
  }
  return GeoLayer(name: name, features: feats, crs: Crs.wgs84, fields: ['name', 'description', 'time']);
}

String _esc(String s) => s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');

String writeGpx(GeoLayer src, {String? nameField}) {
  final layer = src.transformedTo(Crs.wgs84);
  final sb = StringBuffer()
    ..writeln('<?xml version="1.0" encoding="UTF-8"?>')
    ..writeln('<gpx version="1.1" creator="GeoTools" xmlns="http://www.topografix.com/GPX/1/1">');
  String nm(Feature f, int i) {
    final v = nameField == null ? null : f.attrs[nameField];
    return _esc(v?.toString() ?? '$i');
  }

  String pt(String tag, Coord c) =>
      '<$tag lat="${c.y}" lon="${c.x}">${c.z == null ? '' : '<ele>${c.z}</ele>'}';

  var i = 0;
  // النقاط الأول (مواصفة GPX: wpt قبل rte و trk)
  for (final f in layer.features) {
    i++;
    if (f.type != GeomType.point) continue;
    for (final p in f.parts) {
      if (p.isEmpty) continue;
      sb.writeln('${pt('wpt', p.first)}<name>${nm(f, i)}</name></wpt>');
    }
  }
  i = 0;
  for (final f in layer.features) {
    i++;
    if (f.type == GeomType.point || f.isEmpty) continue;
    sb.writeln('<trk><name>${nm(f, i)}</name>');
    for (final p in f.parts) {
      final pts = f.type == GeomType.polygon ? closeRing(p) : p;
      sb.write('<trkseg>');
      for (final c in pts) {
        sb.write('${pt('trkpt', c)}</trkpt>');
      }
      sb.writeln('</trkseg>');
    }
    sb.writeln('</trk>');
  }
  sb.writeln('</gpx>');
  return sb.toString();
}
