import 'dart:convert';
import 'dart:typed_data';

import '../crs/crs.dart';
import '../models/geo.dart';
import '../utils/cp1256.dart';
import '../utils/geometry.dart';
import 'dbf.dart';

// ═════════════════ قراءة ═════════════════

/// [files] = ملفات طبقة واحدة (.shp + .dbf + .prj + .cpg) بنفس الاسم
GeoLayer readShapefile(String name, Map<String, List<int>> files, {TextEnc enc = TextEnc.auto}) {
  final shp = files['shp'];
  if (shp == null) throw const FormatException('ملف .shp مش موجود');
  final dbfBytes = files['dbf'];
  final prj = files['prj'];
  final cpg = files['cpg'];

  final table = dbfBytes == null
      ? DbfTable([], [])
      : readDbf(dbfBytes, enc: enc, cpg: cpg == null ? null : latin1.decode(cpg, allowInvalid: true));
  final shapes = _readShp(shp);

  final features = <Feature>[];
  for (var i = 0; i < shapes.length; i++) {
    final s = shapes[i];
    if (s == null) continue;
    final attrs = i < table.records.length ? Map<String, dynamic>.of(table.records[i]) : <String, dynamic>{};
    features.add(Feature(s.type, s.parts, attrs));
  }

  CrsDef? crs;
  var guessed = false;
  if (prj != null) crs = Crs.fromPrj(utf8.decode(prj, allowMalformed: true));
  if (crs == null) {
    crs = Crs.guessFromCoords(features.expand((f) => f.allCoords));
    guessed = true;
  }
  return GeoLayer(name: name, features: features, crs: crs, fields: List.of(table.fields), crsGuessed: guessed);
}

class _Shape {
  final GeomType type;
  final List<List<Coord>> parts;
  _Shape(this.type, this.parts);
}

List<_Shape?> _readShp(List<int> raw) {
  final bytes = raw is Uint8List ? raw : Uint8List.fromList(raw);
  final bd = ByteData.sublistView(bytes);
  if (bytes.length < 100 || bd.getInt32(0, Endian.big) != 9994) {
    throw const FormatException('ملف .shp غير صالح');
  }
  final fileLen = bd.getInt32(24, Endian.big) * 2;
  final end = fileLen > 0 && fileLen <= bytes.length ? fileLen : bytes.length;
  final out = <_Shape?>[];
  var off = 100;
  while (off + 8 <= end) {
    final contentLen = bd.getInt32(off + 4, Endian.big) * 2;
    final c = off + 8;
    off = c + contentLen;
    if (c + 4 > bytes.length) break;
    final t = bd.getInt32(c, Endian.little);
    switch (t) {
      case 0:
        out.add(null);
        break;
      case 1:
      case 11:
      case 21: {
        final x = bd.getFloat64(c + 4, Endian.little);
        final y = bd.getFloat64(c + 12, Endian.little);
        final z = t == 11 ? bd.getFloat64(c + 20, Endian.little) : null;
        out.add(_Shape(GeomType.point, [
          [Coord(x, y, z)]
        ]));
      }
      case 8:
      case 18:
      case 28: {
        final n = bd.getInt32(c + 36, Endian.little);
        var p = c + 40;
        final zStart = p + 16 * n + 16;
        final parts = <List<Coord>>[];
        for (var i = 0; i < n; i++) {
          final z = t == 18 ? bd.getFloat64(zStart + 8 * i, Endian.little) : null;
          parts.add([Coord(bd.getFloat64(p, Endian.little), bd.getFloat64(p + 8, Endian.little), z)]);
          p += 16;
        }
        out.add(_Shape(GeomType.point, parts));
      }
      case 3:
      case 13:
      case 23:
      case 5:
      case 15:
      case 25: {
        final np = bd.getInt32(c + 36, Endian.little);
        final n = bd.getInt32(c + 40, Endian.little);
        final starts = [for (var i = 0; i < np; i++) bd.getInt32(c + 44 + 4 * i, Endian.little)];
        final ptOff = c + 44 + 4 * np;
        final hasZ = t == 13 || t == 15;
        final zOff = ptOff + 16 * n + 16;
        final parts = <List<Coord>>[];
        for (var i = 0; i < np; i++) {
          final a = starts[i];
          final b = i + 1 < np ? starts[i + 1] : n;
          final ring = <Coord>[];
          for (var k = a; k < b; k++) {
            final x = bd.getFloat64(ptOff + 16 * k, Endian.little);
            final y = bd.getFloat64(ptOff + 16 * k + 8, Endian.little);
            final z = hasZ && zOff + 8 * k + 8 <= bytes.length ? bd.getFloat64(zOff + 8 * k, Endian.little) : null;
            ring.add(Coord(x, y, z));
          }
          parts.add(ring);
        }
        final isPoly = t == 5 || t == 15 || t == 25;
        out.add(_Shape(isPoly ? GeomType.polygon : GeomType.line, parts));
      }
      default:
        out.add(null); // MultiPatch وغيره مش مدعوم
    }
  }
  return out;
}

// ═════════════════ كتابة ═════════════════

/// بيرجع ملفات shapefile. لو الطبقة فيها أكتر من نوع شكل
/// بيطلع shapefile لكل نوع (name_points / name_lines / name_polygons)
List<OutFile> writeShapefile(GeoLayer layer, {TextEnc enc = TextEnc.utf8}) {
  final byType = <GeomType, List<Feature>>{};
  for (final f in layer.features) {
    if (f.isEmpty) continue;
    byType.putIfAbsent(f.type, () => []).add(f);
  }
  final multi = byType.length > 1;
  final out = <OutFile>[];
  for (final e in byType.entries) {
    final suffix = multi
        ? switch (e.key) {
            GeomType.point => '_points',
            GeomType.line => '_lines',
            GeomType.polygon => '_polygons',
          }
        : '';
    final base = '${layer.name}$suffix';
    out.addAll(_writeOne(base, e.key, e.value, layer, enc));
  }
  return out;
}

List<OutFile> _writeOne(String base, GeomType type, List<Feature> feats, GeoLayer layer, TextEnc enc) {
  final isMultiPoint = type == GeomType.point && feats.any((f) => f.parts.length > 1);
  final shapeType = switch (type) {
    GeomType.point => isMultiPoint ? 8 : 1,
    GeomType.line => 3,
    GeomType.polygon => 5,
  };

  // تجهيز المحتوى لكل سجل
  final contents = <Uint8List>[];
  double minX = double.infinity, minY = double.infinity, maxX = -double.infinity, maxY = -double.infinity;
  void ext(Coord c) {
    if (c.x < minX) minX = c.x;
    if (c.y < minY) minY = c.y;
    if (c.x > maxX) maxX = c.x;
    if (c.y > maxY) maxY = c.y;
  }

  for (final f in feats) {
    List<List<Coord>> parts;
    if (type == GeomType.polygon) {
      // الخارجي مع عقارب الساعة، الفتحات عكسها (مواصفة ESRI)
      parts = [];
      for (final poly in groupRings(f.parts)) {
        parts.add(withOrientation(poly.first, clockwise: true));
        for (final h in poly.skip(1)) {
          parts.add(withOrientation(h, clockwise: false));
        }
      }
    } else {
      parts = f.parts.where((p) => p.isNotEmpty).toList();
    }
    final pts = parts.expand((p) => p).toList();
    if (pts.isEmpty) {
      final b = Uint8List(4);
      ByteData.sublistView(b).setInt32(0, 0, Endian.little);
      contents.add(b);
      continue;
    }
    pts.forEach(ext);

    if (shapeType == 1) {
      final b = Uint8List(20);
      final d = ByteData.sublistView(b);
      d.setInt32(0, 1, Endian.little);
      d.setFloat64(4, pts.first.x, Endian.little);
      d.setFloat64(12, pts.first.y, Endian.little);
      contents.add(b);
    } else if (shapeType == 8) {
      final b = Uint8List(40 + 16 * pts.length);
      final d = ByteData.sublistView(b);
      d.setInt32(0, 8, Endian.little);
      _box(d, 4, pts);
      d.setInt32(36, pts.length, Endian.little);
      var o = 40;
      for (final p in pts) {
        d.setFloat64(o, p.x, Endian.little);
        d.setFloat64(o + 8, p.y, Endian.little);
        o += 16;
      }
      contents.add(b);
    } else {
      final np = parts.length;
      final n = pts.length;
      final b = Uint8List(44 + 4 * np + 16 * n);
      final d = ByteData.sublistView(b);
      d.setInt32(0, shapeType, Endian.little);
      _box(d, 4, pts);
      d.setInt32(36, np, Endian.little);
      d.setInt32(40, n, Endian.little);
      var idx = 0;
      for (var i = 0; i < np; i++) {
        d.setInt32(44 + 4 * i, idx, Endian.little);
        idx += parts[i].length;
      }
      var o = 44 + 4 * np;
      for (final p in pts) {
        d.setFloat64(o, p.x, Endian.little);
        d.setFloat64(o + 8, p.y, Endian.little);
        o += 16;
      }
      contents.add(b);
    }
  }
  if (minX == double.infinity) {
    minX = minY = maxX = maxY = 0;
  }

  // SHP
  final shpLen = 100 + contents.fold<int>(0, (s, c) => s + 8 + c.length);
  final shp = Uint8List(shpLen);
  final sd = ByteData.sublistView(shp);
  _header(sd, shpLen, shapeType, minX, minY, maxX, maxY);
  // SHX
  final shxLen = 100 + 8 * contents.length;
  final shx = Uint8List(shxLen);
  final xd = ByteData.sublistView(shx);
  _header(xd, shxLen, shapeType, minX, minY, maxX, maxY);

  var off = 100;
  for (var i = 0; i < contents.length; i++) {
    final c = contents[i];
    sd.setInt32(off, i + 1, Endian.big);
    sd.setInt32(off + 4, c.length ~/ 2, Endian.big);
    shp.setRange(off + 8, off + 8 + c.length, c);
    xd.setInt32(100 + 8 * i, off ~/ 2, Endian.big);
    xd.setInt32(100 + 8 * i + 4, c.length ~/ 2, Endian.big);
    off += 8 + c.length;
  }

  final (dbf, _) = writeDbf(layer.fields, [for (final f in feats) f.attrs], enc: enc);
  final cpg = enc == TextEnc.cp1256 ? '1256' : 'UTF-8';

  return [
    OutFile('$base.shp', shp),
    OutFile('$base.shx', shx),
    OutFile('$base.dbf', dbf),
    OutFile('$base.prj', utf8.encode(layer.crs.prjWkt)),
    OutFile('$base.cpg', ascii.encode(cpg)),
  ];
}

void _box(ByteData d, int o, List<Coord> pts) {
  var a = pts.first.x, b = pts.first.y, c = a, e = b;
  for (final p in pts) {
    if (p.x < a) a = p.x;
    if (p.y < b) b = p.y;
    if (p.x > c) c = p.x;
    if (p.y > e) e = p.y;
  }
  d.setFloat64(o, a, Endian.little);
  d.setFloat64(o + 8, b, Endian.little);
  d.setFloat64(o + 16, c, Endian.little);
  d.setFloat64(o + 24, e, Endian.little);
}

void _header(ByteData d, int byteLen, int shapeType, double minX, double minY, double maxX, double maxY) {
  d.setInt32(0, 9994, Endian.big);
  d.setInt32(24, byteLen ~/ 2, Endian.big);
  d.setInt32(28, 1000, Endian.little);
  d.setInt32(32, shapeType, Endian.little);
  d.setFloat64(36, minX, Endian.little);
  d.setFloat64(44, minY, Endian.little);
  d.setFloat64(52, maxX, Endian.little);
  d.setFloat64(60, maxY, Endian.little);
  // Z و M = صفر
}
