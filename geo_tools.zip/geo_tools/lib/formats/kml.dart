import 'dart:convert';

import 'package:archive/archive.dart';
import 'package:xml/xml.dart';

import '../crs/crs.dart';
import '../models/geo.dart';
import '../utils/geometry.dart';

Iterable<XmlElement> _desc(XmlElement e, String local) =>
    e.descendants.whereType<XmlElement>().where((x) => x.name.local == local);

Iterable<XmlElement> _kids(XmlElement e, String local) =>
    e.children.whereType<XmlElement>().where((x) => x.name.local == local);

XmlElement? _kid(XmlElement e, String local) {
  for (final k in _kids(e, local)) {
    return k;
  }
  return null;
}

List<Coord> _parseCoords(String text) {
  final out = <Coord>[];
  for (final tok in text.trim().split(RegExp(r'\s+'))) {
    if (tok.isEmpty) continue;
    final p = tok.split(',');
    if (p.length < 2) continue;
    final x = double.tryParse(p[0]);
    final y = double.tryParse(p[1]);
    if (x == null || y == null) continue;
    final z = p.length > 2 ? double.tryParse(p[2]) : null;
    out.add(Coord(x, y, z));
  }
  return out;
}

dynamic _autoType(String v) {
  final t = v.trim();
  if (t.isEmpty) return null;
  if (RegExp(r'^-?\d+$').hasMatch(t) && t.length < 16) return int.tryParse(t) ?? t;
  if (RegExp(r'^-?\d*\.\d+$').hasMatch(t)) return double.tryParse(t) ?? t;
  return t;
}

// ═════════════════ قراءة ═════════════════

GeoLayer readKml(String name, List<int> bytes) {
  final doc = XmlDocument.parse(utf8.decode(bytes, allowMalformed: true));
  final root = doc.rootElement;
  final features = <Feature>[];
  final fields = <String>['name'];
  final seen = <String>{'name'};
  void addField(String f) {
    if (seen.add(f)) fields.add(f);
  }

  for (final pm in _desc(root, 'Placemark')) {
    final attrs = <String, dynamic>{};
    final n = _kid(pm, 'name')?.innerText.trim();
    attrs['name'] = (n == null || n.isEmpty) ? null : n;
    final d = _kid(pm, 'description')?.innerText.trim();
    if (d != null && d.isNotEmpty) {
      attrs['description'] = d;
      addField('description');
    }
    // الفولدر الأب
    XmlNode? p = pm.parent;
    while (p is XmlElement) {
      if (p.name.local == 'Folder') {
        final fn = _kid(p, 'name')?.innerText.trim();
        if (fn != null && fn.isNotEmpty) {
          attrs['folder'] = fn;
          addField('folder');
        }
        break;
      }
      p = p.parent;
    }
    final ext = _kid(pm, 'ExtendedData');
    if (ext != null) {
      for (final dEl in _desc(ext, 'Data')) {
        final key = dEl.getAttribute('name');
        if (key == null || key.isEmpty) continue;
        attrs[key] = _autoType(_kid(dEl, 'value')?.innerText ?? '');
        addField(key);
      }
      for (final sd in _desc(ext, 'SimpleData')) {
        final key = sd.getAttribute('name');
        if (key == null || key.isEmpty) continue;
        attrs[key] = _autoType(sd.innerText);
        addField(key);
      }
    }

    final points = <List<Coord>>[];
    final lines = <List<Coord>>[];
    final rings = <List<Coord>>[];
    for (final pt in _desc(pm, 'Point')) {
      final c = _kid(pt, 'coordinates');
      if (c != null) {
        final cs = _parseCoords(c.innerText);
        if (cs.isNotEmpty) points.add([cs.first]);
      }
    }
    for (final ls in _desc(pm, 'LineString')) {
      final c = _kid(ls, 'coordinates');
      if (c != null) {
        final cs = _parseCoords(c.innerText);
        if (cs.length >= 2) lines.add(cs);
      }
    }
    for (final pg in _desc(pm, 'Polygon')) {
      for (final b in [..._kids(pg, 'outerBoundaryIs'), ..._kids(pg, 'innerBoundaryIs')]) {
        for (final lr in _kids(b, 'LinearRing')) {
          final c = _kid(lr, 'coordinates');
          if (c != null) {
            final cs = _parseCoords(c.innerText);
            if (cs.length >= 3) rings.add(closeRing(cs));
          }
        }
      }
    }
    if (points.isNotEmpty) features.add(Feature(GeomType.point, points, Map.of(attrs)));
    if (lines.isNotEmpty) features.add(Feature(GeomType.line, lines, Map.of(attrs)));
    if (rings.isNotEmpty) features.add(Feature(GeomType.polygon, rings, Map.of(attrs)));
  }
  return GeoLayer(name: name, features: features, crs: Crs.wgs84, fields: fields);
}

GeoLayer readKmz(String name, List<int> bytes) {
  final arc = ZipDecoder().decodeBytes(bytes);
  ArchiveFile? kml;
  for (final f in arc.files) {
    if (!f.isFile) continue;
    final n = f.name.toLowerCase();
    if (n.endsWith('.kml')) {
      if (kml == null || n.endsWith('doc.kml')) kml = f;
    }
  }
  if (kml == null) throw const FormatException('مفيش ملف KML جوه الـ KMZ');
  return readKml(name, kml.content as List<int>);
}

// ═════════════════ كتابة ═════════════════

String _esc(String s) => s
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;');

String _coordsStr(List<Coord> cs) =>
    cs.map((c) => c.z == null ? '${c.x},${c.y}' : '${c.x},${c.y},${c.z}').join(' ');

/// اختيار الحقل اللي هيبقى اسم العنصر
String? pickNameField(GeoLayer l) {
  const prefs = ['name', 'Name', 'NAME', 'الاسم', 'اسم', 'id', 'ID', 'رقم', 'رقم_القطعة', 'plot', 'parcel'];
  for (final p in prefs) {
    if (l.fields.contains(p)) return p;
  }
  return l.fields.isEmpty ? null : l.fields.first;
}

String writeKml(GeoLayer src, {String? nameField}) {
  final layer = src.transformedTo(Crs.wgs84);
  final nf = nameField ?? pickNameField(layer);
  final sb = StringBuffer()
    ..writeln('<?xml version="1.0" encoding="UTF-8"?>')
    ..writeln('<kml xmlns="http://www.opengis.net/kml/2.2">')
    ..writeln('<Document>')
    ..writeln('<name>${_esc(layer.name)}</name>')
    ..writeln('<Style id="pt"><IconStyle><scale>1.0</scale><Icon><href>http://maps.google.com/mapfiles/kml/paddle/red-circle.png</href></Icon></IconStyle></Style>')
    ..writeln('<Style id="ln"><LineStyle><color>ff00a5ff</color><width>3</width></LineStyle></Style>')
    ..writeln('<Style id="pg"><LineStyle><color>ff0000ff</color><width>2</width></LineStyle><PolyStyle><color>4d00ffff</color></PolyStyle></Style>');

  var i = 0;
  for (final f in layer.features) {
    i++;
    if (f.isEmpty) continue;
    final nm = nf == null ? null : f.attrs[nf];
    sb.writeln('<Placemark>');
    sb.writeln('<name>${_esc(nm?.toString() ?? '$i')}</name>');
    final desc = f.attrs['description'];
    if (desc != null && nf != 'description') sb.writeln('<description>${_esc(desc.toString())}</description>');
    sb.writeln('<styleUrl>#${switch (f.type) { GeomType.point => 'pt', GeomType.line => 'ln', GeomType.polygon => 'pg' }}</styleUrl>');
    final keys = layer.fields.where((k) => f.attrs[k] != null).toList();
    if (keys.isNotEmpty) {
      sb.writeln('<ExtendedData>');
      for (final k in keys) {
        sb.writeln('<Data name="${_esc(k)}"><value>${_esc(f.attrs[k].toString())}</value></Data>');
      }
      sb.writeln('</ExtendedData>');
    }
    final geoms = <String>[];
    switch (f.type) {
      case GeomType.point:
        for (final p in f.parts) {
          if (p.isNotEmpty) geoms.add('<Point><coordinates>${_coordsStr([p.first])}</coordinates></Point>');
        }
        break;
      case GeomType.line:
        for (final p in f.parts) {
          if (p.length >= 2) {
            geoms.add('<LineString><tessellate>1</tessellate><coordinates>${_coordsStr(p)}</coordinates></LineString>');
          }
        }
        break;
      case GeomType.polygon:
        for (final poly in groupRings(f.parts)) {
          final g = StringBuffer('<Polygon><outerBoundaryIs><LinearRing><coordinates>')
            ..write(_coordsStr(withOrientation(poly.first, clockwise: false)))
            ..write('</coordinates></LinearRing></outerBoundaryIs>');
          for (final h in poly.skip(1)) {
            g.write('<innerBoundaryIs><LinearRing><coordinates>${_coordsStr(withOrientation(h, clockwise: true))}</coordinates></LinearRing></innerBoundaryIs>');
          }
          g.write('</Polygon>');
          geoms.add(g.toString());
        }
        break;
    }
    if (geoms.length == 1) {
      sb.writeln(geoms.first);
    } else if (geoms.isNotEmpty) {
      sb.writeln('<MultiGeometry>${geoms.join()}</MultiGeometry>');
    }
    sb.writeln('</Placemark>');
  }
  sb
    ..writeln('</Document>')
    ..writeln('</kml>');
  return sb.toString();
}

List<int> writeKmz(GeoLayer layer, {String? nameField}) {
  final data = utf8.encode(writeKml(layer, nameField: nameField));
  final arc = Archive()..addFile(ArchiveFile('doc.kml', data.length, data));
  return ZipEncoder().encode(arc)!;
}
