import 'dart:convert';
import 'dart:typed_data';

import 'package:csv/csv.dart';
import 'package:excel/excel.dart' as xl;

import '../crs/crs.dart';
import '../models/geo.dart';
import '../utils/cp1256.dart';
import '../utils/geometry.dart';

const summarySheetName = 'ملخص العناصر';
const infoSheetName = 'معلومات';

/// جدول خام (من Excel أو CSV)
class RawTable {
  final String name;
  final List<String> headers;
  final List<List<dynamic>> rows;
  RawTable(this.name, this.headers, this.rows);
}

// ═════════════════ قراءة Excel / CSV ═════════════════

dynamic _cellValue(xl.CellValue? v) {
  if (v == null) return null;
  if (v is xl.TextCellValue) {
    final t = v.toString();
    return t.trim().isEmpty ? null : t.trim();
  }
  if (v is xl.IntCellValue) return v.value;
  if (v is xl.DoubleCellValue) return v.value;
  if (v is xl.BoolCellValue) return v.value;
  if (v is xl.FormulaCellValue) return v.formula;
  return v.toString();
}

/// يقرأ كل الشيتات اللي فيها بيانات (أول صف = عناوين)
List<RawTable> readExcel(String name, List<int> bytes) {
  final book = xl.Excel.decodeBytes(bytes);
  final out = <RawTable>[];
  for (final entry in book.tables.entries) {
    // شيتات الملخص اللي البرنامج بيكتبها مش بيانات إحداثيات
    if (entry.key == summarySheetName || entry.key == infoSheetName) continue;
    final rows = entry.value.rows;
    // أول صف مش فاضي = العناوين
    var h = 0;
    while (h < rows.length && rows[h].every((c) => _cellValue(c?.value) == null)) {
      h++;
    }
    if (h >= rows.length) continue;
    final headerRow = rows[h];
    final headers = <String>[];
    for (var i = 0; i < headerRow.length; i++) {
      final v = _cellValue(headerRow[i]?.value);
      headers.add(v == null ? 'col${i + 1}' : v.toString());
    }
    final data = <List<dynamic>>[];
    for (var r = h + 1; r < rows.length; r++) {
      final row = [for (var i = 0; i < headers.length; i++) i < rows[r].length ? _cellValue(rows[r][i]?.value) : null];
      if (row.every((v) => v == null)) continue;
      data.add(row);
    }
    final sheetName = book.tables.length > 1 ? '${name}_${entry.key}' : name;
    out.add(RawTable(sheetName, headers, data));
  }
  return out;
}

RawTable readCsv(String name, List<int> bytes, {TextEnc enc = TextEnc.auto}) {
  final text = decodeText(bytes, enc);
  final firstLine = text.split(RegExp(r'\r?\n')).firstWhere((l) => l.trim().isNotEmpty, orElse: () => '');
  String delim = ',';
  final counts = {',': ','.allMatches(firstLine).length, ';': ';'.allMatches(firstLine).length, '\t': '\t'.allMatches(firstLine).length};
  var best = 0;
  counts.forEach((k, v) {
    if (v > best) {
      best = v;
      delim = k;
    }
  });
  final rows = CsvToListConverter(fieldDelimiter: delim, eol: '\n', shouldParseNumbers: true)
      .convert(text.replaceAll('\r\n', '\n').replaceAll('\r', '\n'));
  final nonEmpty = rows.where((r) => r.any((v) => v.toString().trim().isNotEmpty)).toList();
  if (nonEmpty.isEmpty) return RawTable(name, [], []);
  final headers = [for (var i = 0; i < nonEmpty.first.length; i++) nonEmpty.first[i].toString().trim().isEmpty ? 'col${i + 1}' : nonEmpty.first[i].toString().trim()];
  final data = [
    for (final r in nonEmpty.skip(1))
      [
        for (var i = 0; i < headers.length; i++)
          i < r.length ? (r[i] is String && (r[i] as String).trim().isEmpty ? null : (r[i] is String ? (r[i] as String).trim() : r[i])) : null
      ]
  ];
  return RawTable(name, headers, data);
}

// ═════════════════ تحويل الجدول لطبقة ═════════════════

class TableMapping {
  int xCol;
  int yCol;
  int? zCol;
  int? groupCol; // عمود رقم القطعة/الخط — النقاط بنفس الرقم بتتجمع
  int? typeCol; // عمود نوع الشكل (من تصدير البرنامج نفسه)
  int? partCol;
  GeomType geomType;
  CrsDef crs;

  TableMapping({
    required this.xCol,
    required this.yCol,
    this.zCol,
    this.groupCol,
    this.typeCol,
    this.partCol,
    this.geomType = GeomType.point,
    required this.crs,
  });
}

int? _findCol(List<String> h, List<String> names) {
  final low = [for (final x in h) x.trim().toLowerCase()];
  for (final n in names) {
    final i = low.indexOf(n.toLowerCase());
    if (i >= 0) return i;
  }
  for (final n in names) {
    if (n.length < 3) continue;
    final i = low.indexWhere((x) => x.contains(n.toLowerCase()));
    if (i >= 0) return i;
  }
  return null;
}

const _xNames = ['x', 'easting', 'east', 'lon', 'long', 'lng', 'longitude', 'شرقيات', 'شرقي', 'الشرقيات', 'خط الطول', 'طول', 'e'];
const _yNames = ['y', 'northing', 'north', 'lat', 'latitude', 'شماليات', 'شمالي', 'الشماليات', 'خط العرض', 'عرض', 'n'];
const _zNames = ['z', 'elevation', 'ele', 'alt', 'altitude', 'height', 'منسوب', 'المنسوب', 'ارتفاع'];
const _groupNames = ['feature_id', 'id_قطعة', 'رقم القطعة', 'رقم_القطعة', 'القطعة', 'parcel', 'plot', 'group', 'id'];

/// تخمين أولي للأعمدة
TableMapping guessMapping(RawTable t) {
  final x = _findCol(t.headers, _xNames) ?? 0;
  var y = _findCol(t.headers, _yNames) ?? (t.headers.length > 1 ? 1 : 0);
  if (y == x && t.headers.length > 1) y = x == 0 ? 1 : 0;
  final z = _findCol(t.headers, _zNames);
  final typeCol = t.headers.indexOf('geom_type');
  final partCol = t.headers.indexOf('part');
  final g = typeCol >= 0 ? t.headers.indexOf('feature_id') : null;

  final sample = <Coord>[];
  for (final r in t.rows.take(500)) {
    final a = parseCoordValue(r[x]);
    final b = parseCoordValue(r[y]);
    if (a != null && b != null) sample.add(Coord(a, b));
  }
  return TableMapping(
    xCol: x,
    yCol: y,
    zCol: (z == x || z == y) ? null : z,
    groupCol: (g != null && g >= 0) ? g : null,
    typeCol: typeCol >= 0 ? typeCol : null,
    partCol: partCol >= 0 ? partCol : null,
    geomType: GeomType.point,
    crs: Crs.guessFromCoords(sample),
  );
}

/// ملف متصدّر من البرنامج نفسه (فيه feature_id / geom_type / vertex)
bool isOwnExport(RawTable t) =>
    t.headers.contains('feature_id') && t.headers.contains('geom_type') && t.headers.contains('vertex');

List<int> groupColumnCandidates(RawTable t) {
  final i = _findCol(t.headers, _groupNames);
  return i == null ? [] : [i];
}

/// الأعمدة اللي اتخصصت للإحداثيات مش بتتنقل كبيانات وصفية
GeoLayer tableToLayer(RawTable t, TableMapping m) {
  final skip = {m.xCol, m.yCol, if (m.zCol != null) m.zCol!, if (m.typeCol != null) m.typeCol!, if (m.partCol != null) m.partCol!};
  // أعمدة vertex من تصدير البرنامج
  final vIdx = t.headers.indexOf('vertex');
  if (m.typeCol != null && vIdx >= 0) skip.add(vIdx);
  final attrCols = [for (var i = 0; i < t.headers.length; i++) if (!skip.contains(i)) i];
  final fields = [for (final i in attrCols) t.headers[i]];

  Map<String, dynamic> attrsOf(List<dynamic> r) => {for (final i in attrCols) t.headers[i]: r[i]};

  Coord? coordOf(List<dynamic> r) {
    final x = parseCoordValue(r[m.xCol]);
    final y = parseCoordValue(r[m.yCol]);
    if (x == null || y == null) return null;
    final z = m.zCol == null ? null : parseCoordValue(r[m.zCol!]);
    return Coord(x, y, z);
  }

  final feats = <Feature>[];
  if (m.groupCol == null) {
    if (m.geomType == GeomType.point) {
      for (final r in t.rows) {
        final c = coordOf(r);
        if (c == null) continue;
        feats.add(Feature(GeomType.point, [
          [c]
        ], attrsOf(r)));
      }
    } else {
      // كل الصفوف = شكل واحد
      final pts = [for (final r in t.rows) coordOf(r)].whereType<Coord>().toList();
      if (pts.isNotEmpty) {
        feats.add(Feature(m.geomType, [m.geomType == GeomType.polygon ? closeRing(pts) : pts],
            t.rows.isEmpty ? {} : attrsOf(t.rows.first)));
      }
    }
  } else {
    // تجميع حسب العمود — مع الحفاظ على الترتيب
    final order = <String>[];
    final groups = <String, List<List<dynamic>>>{};
    for (final r in t.rows) {
      final k = (r[m.groupCol!] ?? '').toString();
      if (!groups.containsKey(k)) {
        order.add(k);
        groups[k] = [];
      }
      groups[k]!.add(r);
    }
    for (final k in order) {
      final rows = groups[k]!;
      var type = m.geomType;
      if (m.typeCol != null) type = GeomTypeX.fromKey(rows.first[m.typeCol!]?.toString()) ?? type;
      // تقسيم لأجزاء لو فيه عمود part
      final parts = <String, List<Coord>>{};
      final partOrder = <String>[];
      for (final r in rows) {
        final c = coordOf(r);
        if (c == null) continue;
        final pk = m.partCol == null ? '0' : (r[m.partCol!] ?? '0').toString();
        if (!parts.containsKey(pk)) {
          partOrder.add(pk);
          parts[pk] = [];
        }
        parts[pk]!.add(c);
      }
      var ps = [for (final pk in partOrder) parts[pk]!];
      if (type == GeomType.polygon) {
        ps = [for (final p in ps) if (p.length >= 3) closeRing(p)];
      } else if (type == GeomType.point) {
        // نقاط متجمعة = MultiPoint
        ps = [for (final p in ps) for (final c in p) [c]];
      }
      if (ps.isEmpty) continue;
      feats.add(Feature(type, ps, attrsOf(rows.first)));
    }
  }
  return GeoLayer(name: t.name, features: feats, crs: m.crs, fields: fields);
}

// ═════════════════ كتابة Excel / CSV ═════════════════

/// صفوف الإحداثيات (صف لكل رأس) — بيرجع يتقري تاني بنفس البرنامج
(List<String>, List<List<dynamic>>) _vertexRows(GeoLayer layer, {bool includeMeasures = false}) {
  final geo = layer.crs.geographic;
  final hasZ = layer.features.any((f) => f.allCoords.any((c) => c.z != null));
  final measurer = includeMeasures ? Measurer(layer.crs, sample: layer.features.expand((f) => f.allCoords).firstOrNull) : null;
  final onlyPoints = layer.features.every((f) => f.type == GeomType.point && f.parts.length <= 1);

  final headers = <String>[
    if (!onlyPoints) ...['feature_id', 'geom_type', 'part', 'vertex'],
    geo ? 'longitude' : 'X',
    geo ? 'latitude' : 'Y',
    if (hasZ) 'Z',
    ...layer.fields,
    if (includeMeasures && !onlyPoints) ...['area_m2', 'area_feddan', 'perimeter_m', 'length_m'],
  ];
  final rows = <List<dynamic>>[];
  var fid = 0;
  for (final f in layer.features) {
    fid++;
    final ms = measurer?.of(f);
    var parts = f.parts;
    if (f.type == GeomType.polygon) parts = [for (final r in parts) closeRing(r)];
    for (var p = 0; p < parts.length; p++) {
      for (var v = 0; v < parts[p].length; v++) {
        final c = parts[p][v];
        rows.add([
          if (!onlyPoints) ...[fid, f.type.key, p + 1, v + 1],
          c.x,
          c.y,
          if (hasZ) c.z,
          for (final k in layer.fields) f.attrs[k],
          if (includeMeasures && !onlyPoints) ...[
            ms == null || ms.area == 0 ? null : double.parse(ms.area.toStringAsFixed(2)),
            ms == null || ms.area == 0 ? null : feddanText(ms.area),
            ms == null || ms.perimeter == 0 ? null : double.parse(ms.perimeter.toStringAsFixed(2)),
            ms == null || ms.length == 0 ? null : double.parse(ms.length.toStringAsFixed(2)),
          ],
        ]);
      }
    }
  }
  return (headers, rows);
}

xl.CellValue? _toCell(dynamic v) {
  if (v == null) return null;
  if (v is int) return xl.IntCellValue(v);
  if (v is double) return xl.DoubleCellValue(v);
  if (v is bool) return xl.BoolCellValue(v);
  return xl.TextCellValue(v.toString());
}

List<int> writeExcel(GeoLayer layer, {bool includeMeasures = true}) {
  final book = xl.Excel.createExcel();
  final defaultName = book.getDefaultSheet() ?? 'Sheet1';
  const dataName = 'الإحداثيات';
  book.rename(defaultName, dataName);
  final sheet = book[dataName];
  final (headers, rows) = _vertexRows(layer, includeMeasures: false);
  sheet.appendRow([for (final h in headers) xl.TextCellValue(h)]);
  for (final r in rows) {
    sheet.appendRow([for (final v in r) _toCell(v)]);
  }

  // شيت ملخص: صف لكل عنصر مع المساحة
  if (includeMeasures && layer.features.any((f) => f.type != GeomType.point)) {
    final s2 = book[summarySheetName];
    final m = Measurer(layer.crs, sample: layer.features.expand((f) => f.allCoords).firstOrNull);
    s2.appendRow([
      for (final h in ['feature_id', 'geom_type', ...layer.fields, 'المساحة م²', 'فدان/قيراط/سهم', 'المحيط م', 'الطول م'])
        xl.TextCellValue(h)
    ]);
    var fid = 0;
    var total = 0.0;
    for (final f in layer.features) {
      fid++;
      final ms = m.of(f);
      total += ms.area;
      s2.appendRow([
        xl.IntCellValue(fid),
        xl.TextCellValue(f.type.key),
        for (final k in layer.fields) _toCell(f.attrs[k]),
        ms.area == 0 ? null : xl.DoubleCellValue(double.parse(ms.area.toStringAsFixed(2))),
        ms.area == 0 ? null : xl.TextCellValue(feddanText(ms.area)),
        ms.perimeter == 0 ? null : xl.DoubleCellValue(double.parse(ms.perimeter.toStringAsFixed(2))),
        ms.length == 0 ? null : xl.DoubleCellValue(double.parse(ms.length.toStringAsFixed(2))),
      ]);
    }
    if (total > 0) {
      s2.appendRow([]);
      s2.appendRow([
        xl.TextCellValue('الإجمالي'),
        null,
        for (final _ in layer.fields) null,
        xl.DoubleCellValue(double.parse(total.toStringAsFixed(2))),
        xl.TextCellValue(feddanText(total)),
      ]);
    }
  }
  final info = book[infoSheetName];
  info.appendRow([xl.TextCellValue('نظام الإحداثيات'), xl.TextCellValue(layer.crs.label)]);
  info.appendRow([xl.TextCellValue('عدد العناصر'), xl.IntCellValue(layer.features.length)]);

  return book.encode()!;
}

List<int> writeCsv(GeoLayer layer) {
  final (headers, rows) = _vertexRows(layer, includeMeasures: true);
  final csv = ListToCsvConverter().convert([headers, ...rows.map((r) => r.map((v) => v ?? '').toList())]);
  // BOM عشان Excel يقرأ العربي صح
  return Uint8List.fromList([0xEF, 0xBB, 0xBF, ...utf8.encode(csv)]);
}
