import 'dart:convert';

import 'package:archive/archive.dart';

import '../crs/crs.dart';
import '../models/geo.dart';
import '../utils/cp1256.dart';
import 'dxf.dart';
import 'geojson.dart';
import 'gpx.dart';
import 'kml.dart';
import 'shapefile.dart';
import 'table.dart';

enum GeoFormat { excel, csv, kml, kmz, shapefile, geojson, dxf, gpx }

extension GeoFormatX on GeoFormat {
  String get label => switch (this) {
        GeoFormat.excel => 'Excel',
        GeoFormat.csv => 'CSV',
        GeoFormat.kml => 'KML',
        GeoFormat.kmz => 'KMZ',
        GeoFormat.shapefile => 'Shapefile',
        GeoFormat.geojson => 'GeoJSON',
        GeoFormat.dxf => 'DXF (AutoCAD)',
        GeoFormat.gpx => 'GPX',
      };

  String get ext => switch (this) {
        GeoFormat.excel => 'xlsx',
        GeoFormat.csv => 'csv',
        GeoFormat.kml => 'kml',
        GeoFormat.kmz => 'kmz',
        GeoFormat.shapefile => 'zip',
        GeoFormat.geojson => 'geojson',
        GeoFormat.dxf => 'dxf',
        GeoFormat.gpx => 'gpx',
      };

  /// الصيغ دي لازم تكون WGS84 حسب المواصفة
  bool get forcesWgs84 => this == GeoFormat.kml || this == GeoFormat.kmz || this == GeoFormat.geojson || this == GeoFormat.gpx;
}

/// نتيجة فتح الملفات: طبقات جاهزة + جداول محتاجة تحديد أعمدة الإحداثيات
class LoadResult {
  final List<GeoLayer> layers = [];
  final List<RawTable> tables = [];
  final List<String> warnings = [];
}

const supportedExtensions = ['xlsx', 'csv', 'txt', 'kml', 'kmz', 'shp', 'dbf', 'shx', 'prj', 'cpg', 'zip', 'geojson', 'json', 'dxf', 'gpx'];

LoadResult loadFiles(List<InFile> input, {TextEnc enc = TextEnc.auto}) {
  final res = LoadResult();
  // نفك أي zip الأول
  final files = <InFile>[];
  for (final f in input) {
    if (f.ext == 'zip') {
      try {
        final arc = ZipDecoder().decodeBytes(f.bytes);
        for (final a in arc.files) {
          if (!a.isFile) continue;
          if (a.name.contains('__MACOSX')) continue;
          files.add(InFile(a.name, a.content as List<int>));
        }
      } catch (e) {
        res.warnings.add('${f.name}: ملف zip تالف');
      }
    } else {
      files.add(f);
    }
  }

  // ملفات الشيب: نجمعهم بالاسم
  final shpGroups = <String, Map<String, List<int>>>{};
  for (final f in files) {
    if (['shp', 'dbf', 'shx', 'prj', 'cpg'].contains(f.ext)) {
      shpGroups.putIfAbsent(f.baseName, () => {})[f.ext] = f.bytes;
    }
  }
  for (final e in shpGroups.entries) {
    if (!e.value.containsKey('shp')) {
      res.warnings.add('${e.key}: ناقص ملف .shp (لازم تختار .shp و .dbf و .prj مع بعض أو ملف zip)');
      continue;
    }
    if (!e.value.containsKey('dbf')) res.warnings.add('${e.key}: مفيش .dbf — هيتحول من غير بيانات وصفية');
    try {
      final l = readShapefile(e.key, e.value, enc: enc);
      if (!e.value.containsKey('prj')) res.warnings.add('${e.key}: مفيش .prj — نظام الإحداثيات متخمن، راجعه');
      res.layers.add(l);
    } catch (err) {
      res.warnings.add('${e.key}: $err');
    }
  }

  for (final f in files) {
    try {
      switch (f.ext) {
        case 'kml':
          res.layers.add(readKml(f.baseName, f.bytes));
          break;
        case 'kmz':
          res.layers.add(readKmz(f.baseName, f.bytes));
          break;
        case 'geojson':
        case 'json':
          res.layers.add(readGeoJson(f.baseName, f.bytes));
          break;
        case 'gpx':
          res.layers.add(readGpx(f.baseName, f.bytes));
          break;
        case 'dxf':
          res.layers.add(readDxf(f.baseName, f.bytes));
          break;
        case 'xlsx':
          res.tables.addAll(readExcel(f.baseName, f.bytes));
          break;
        case 'xls':
          res.warnings.add('${f.name}: صيغة xls القديمة مش مدعومة — احفظه xlsx من Excel');
          break;
        case 'csv':
        case 'txt':
          res.tables.add(readCsv(f.baseName, f.bytes, enc: enc));
          break;
        case 'shp':
        case 'dbf':
        case 'shx':
        case 'prj':
        case 'cpg':
          break; // اتعملوا فوق
        default:
          res.warnings.add('${f.name}: صيغة مش مدعومة');
      }
    } catch (err) {
      res.warnings.add('${f.name}: خطأ في القراءة — $err');
    }
  }
  for (final l in res.layers) {
    if (l.features.isEmpty) res.warnings.add('${l.name}: مفيش عناصر جغرافية');
  }
  return res;
}

class WriteOptions {
  final CrsDef? targetCrs; // للصيغ اللي مش WGS84 إجباري
  final String? nameField;
  final bool addMeasures;
  final TextEnc dbfEncoding;
  const WriteOptions({this.targetCrs, this.nameField, this.addMeasures = true, this.dbfEncoding = TextEnc.utf8});
}

List<OutFile> writeLayer(GeoLayer src, GeoFormat fmt, WriteOptions o) {
  final layer = (!fmt.forcesWgs84 && o.targetCrs != null) ? src.transformedTo(o.targetCrs!) : src;
  final n = layer.name;
  return switch (fmt) {
    GeoFormat.excel => [OutFile('$n.xlsx', writeExcel(layer, includeMeasures: o.addMeasures))],
    GeoFormat.csv => [OutFile('$n.csv', writeCsv(layer))],
    GeoFormat.kml => [OutFile('$n.kml', utf8.encode(writeKml(layer, nameField: o.nameField)))],
    GeoFormat.kmz => [OutFile('$n.kmz', writeKmz(layer, nameField: o.nameField))],
    GeoFormat.shapefile => writeShapefile(layer, enc: o.dbfEncoding),
    GeoFormat.geojson => [OutFile('$n.geojson', utf8.encode(writeGeoJson(layer)))],
    GeoFormat.dxf => [OutFile('$n.dxf', writeDxf(layer, labelField: o.nameField))],
    GeoFormat.gpx => [OutFile('$n.gpx', utf8.encode(writeGpx(layer, nameField: o.nameField)))],
  };
}

/// لو ملف واحد يرجع زي ما هو، لو أكتر يتضغطوا zip
OutFile packOutputs(List<OutFile> files, String zipName) {
  if (files.length == 1) return files.first;
  final arc = Archive();
  for (final f in files) {
    arc.addFile(ArchiveFile(f.name, f.bytes.length, f.bytes));
  }
  return OutFile('$zipName.zip', ZipEncoder().encode(arc)!);
}

/// تنظيف اسم الملف
String safeFileName(String s) {
  final t = s.trim().replaceAll(RegExp(r'[\\/:*?"<>|]+'), '_');
  return t.isEmpty ? 'output' : t;
}
