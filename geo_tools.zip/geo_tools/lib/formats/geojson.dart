import 'dart:convert';

import '../crs/crs.dart';
import '../models/geo.dart';
import '../utils/geometry.dart';

List<Coord> _line(dynamic arr) => [
      for (final c in (arr as List))
        if (c is List && c.length >= 2)
          Coord((c[0] as num).toDouble(), (c[1] as num).toDouble(), c.length > 2 && c[2] is num ? (c[2] as num).toDouble() : null)
    ];

List<Feature> _geomToFeatures(Map<String, dynamic>? g, Map<String, dynamic> attrs) {
  if (g == null) return [];
  final type = g['type'];
  final c = g['coordinates'];
  switch (type) {
    case 'Point':
      return [
        Feature(GeomType.point, [_line([c])], attrs)
      ];
    case 'MultiPoint':
      return [
        Feature(GeomType.point, [for (final p in c as List) _line([p])], attrs)
      ];
    case 'LineString':
      return [
        Feature(GeomType.line, [_line(c)], attrs)
      ];
    case 'MultiLineString':
      return [
        Feature(GeomType.line, [for (final l in c as List) _line(l)], attrs)
      ];
    case 'Polygon':
      return [
        Feature(GeomType.polygon, [for (final r in c as List) _line(r)], attrs)
      ];
    case 'MultiPolygon':
      return [
        Feature(GeomType.polygon, [
          for (final poly in c as List)
            for (final r in poly as List) _line(r)
        ], attrs)
      ];
    case 'GeometryCollection':
      return [
        for (final sub in (g['geometries'] as List? ?? []))
          ..._geomToFeatures((sub as Map).cast<String, dynamic>(), Map.of(attrs))
      ];
  }
  return [];
}

GeoLayer readGeoJson(String name, List<int> bytes) {
  final j = jsonDecode(utf8.decode(bytes, allowMalformed: true));
  final feats = <Feature>[];
  final fields = <String>[];
  final seen = <String>{};

  void addFeature(Map<String, dynamic> f) {
    final props = (f['properties'] as Map?)?.cast<String, dynamic>() ?? <String, dynamic>{};
    final attrs = <String, dynamic>{};
    props.forEach((k, v) {
      if (seen.add(k)) fields.add(k);
      attrs[k] = (v is Map || v is List) ? jsonEncode(v) : v;
    });
    feats.addAll(_geomToFeatures((f['geometry'] as Map?)?.cast<String, dynamic>(), attrs));
  }

  if (j is Map && j['type'] == 'FeatureCollection') {
    for (final f in (j['features'] as List? ?? [])) {
      addFeature((f as Map).cast<String, dynamic>());
    }
  } else if (j is Map && j['type'] == 'Feature') {
    addFeature(j.cast<String, dynamic>());
  } else if (j is Map) {
    feats.addAll(_geomToFeatures(j.cast<String, dynamic>(), {}));
  }

  // GeoJSON القياسي WGS84 — بس نشوف لو فيه crs قديم أو أرقام مترية
  CrsDef crs = Crs.wgs84;
  var guessed = false;
  if (j is Map && j['crs'] is Map) {
    final n = ((j['crs'] as Map)['properties'] as Map?)?['name']?.toString() ?? '';
    final m = RegExp(r'(\d{4,5})\s*$').firstMatch(n);
    final byCode = m == null ? null : Crs.byEpsg(int.parse(m.group(1)!));
    if (byCode != null) crs = byCode;
  } else {
    final g = Crs.guessFromCoords(feats.expand((f) => f.allCoords));
    if (!g.geographic) {
      crs = g;
      guessed = true;
    }
  }
  return GeoLayer(name: name, features: feats, crs: crs, fields: fields, crsGuessed: guessed);
}

List<List<double>> _arr(List<Coord> cs) => [
      for (final c in cs) c.z == null ? [c.x, c.y] : [c.x, c.y, c.z!]
    ];

Map<String, dynamic>? _geom(Feature f) {
  final parts = f.parts.where((p) => p.isNotEmpty).toList();
  if (parts.isEmpty) return null;
  switch (f.type) {
    case GeomType.point:
      return parts.length == 1
          ? {'type': 'Point', 'coordinates': _arr([parts.first.first]).first}
          : {'type': 'MultiPoint', 'coordinates': [for (final p in parts) _arr([p.first]).first]};
    case GeomType.line:
      return parts.length == 1
          ? {'type': 'LineString', 'coordinates': _arr(parts.first)}
          : {'type': 'MultiLineString', 'coordinates': [for (final p in parts) _arr(p)]};
    case GeomType.polygon:
      final polys = [
        for (final poly in groupRings(parts))
          [
            _arr(withOrientation(poly.first, clockwise: false)),
            for (final h in poly.skip(1)) _arr(withOrientation(h, clockwise: true)),
          ]
      ];
      return polys.length == 1
          ? {'type': 'Polygon', 'coordinates': polys.first}
          : {'type': 'MultiPolygon', 'coordinates': polys};
  }
}

String writeGeoJson(GeoLayer src) {
  final layer = src.transformedTo(Crs.wgs84);
  final out = {
    'type': 'FeatureCollection',
    'name': layer.name,
    'features': [
      for (final f in layer.features)
        {
          'type': 'Feature',
          'properties': {for (final k in layer.fields) k: f.attrs[k]},
          'geometry': _geom(f),
        }
    ],
  };
  return const JsonEncoder.withIndent(' ').convert(out);
}
