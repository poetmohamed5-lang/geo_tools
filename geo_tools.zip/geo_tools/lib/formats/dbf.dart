import 'dart:convert';
import 'dart:typed_data';

import '../utils/cp1256.dart';

class DbfTable {
  final List<String> fields;
  final List<Map<String, dynamic>> records;
  DbfTable(this.fields, this.records);
}

// ───────────────── قراءة ─────────────────

DbfTable readDbf(List<int> raw, {TextEnc enc = TextEnc.auto, String? cpg}) {
  final bytes = raw is Uint8List ? raw : Uint8List.fromList(raw);
  final bd = ByteData.sublistView(bytes);
  if (bytes.length < 32) return DbfTable([], []);
  final nRec = bd.getUint32(4, Endian.little);
  final headerLen = bd.getUint16(8, Endian.little);
  final recLen = bd.getUint16(10, Endian.little);

  // تحديد الترميز
  var useEnc = enc;
  if (useEnc == TextEnc.auto && cpg != null) {
    final c = cpg.trim().toUpperCase();
    if (c.contains('UTF')) {
      useEnc = TextEnc.utf8;
    } else if (c.contains('1256')) {
      useEnc = TextEnc.cp1256;
    }
  }

  final names = <String>[];
  final types = <String>[];
  final lens = <int>[];
  var off = 32;
  while (off + 32 <= headerLen && bytes[off] != 0x0D) {
    var end = off;
    while (end < off + 11 && bytes[end] != 0) {
      end++;
    }
    final nameBytes = bytes.sublist(off, end);
    names.add(isValidUtf8(nameBytes) ? utf8.decode(nameBytes).trim() : decodeCp1256(nameBytes).trim());
    types.add(String.fromCharCode(bytes[off + 11]).toUpperCase());
    lens.add(bytes[off + 16]);
    off += 32;
  }

  // لو تلقائي: نشوف كل النصوص UTF-8 سليم ولا لأ
  if (useEnc == TextEnc.auto) {
    var ok = true;
    for (var r = 0; r < nRec && ok; r++) {
      var p = headerLen + r * recLen + 1;
      for (var f = 0; f < names.length; f++) {
        if (types[f] == 'C' && p + lens[f] <= bytes.length) {
          if (!isValidUtf8(bytes.sublist(p, p + lens[f]))) {
            ok = false;
            break;
          }
        }
        p += lens[f];
      }
    }
    useEnc = ok ? TextEnc.utf8 : TextEnc.cp1256;
  }

  final records = <Map<String, dynamic>>[];
  for (var r = 0; r < nRec; r++) {
    final start = headerLen + r * recLen;
    if (start + recLen > bytes.length) break;
    var p = start + 1; // بايت علامة الحذف
    final rec = <String, dynamic>{};
    for (var f = 0; f < names.length; f++) {
      final chunk = bytes.sublist(p, p + lens[f]);
      p += lens[f];
      final t = types[f];
      if (t == 'N' || t == 'F' || t == 'O' || t == 'I' || t == 'B') {
        final s = latin1.decode(chunk, allowInvalid: true).trim();
        if (s.isEmpty || s.startsWith('*')) {
          rec[names[f]] = null;
        } else {
          final n = num.tryParse(s);
          rec[names[f]] = n == null ? s : (n is double && n == n.truncateToDouble() && !s.contains('.') ? n.toInt() : n);
        }
      } else if (t == 'L') {
        final s = latin1.decode(chunk, allowInvalid: true).trim().toUpperCase();
        rec[names[f]] = s.isEmpty || s == '?' ? null : 'YT'.contains(s[0]);
      } else if (t == 'D') {
        final s = latin1.decode(chunk, allowInvalid: true).trim();
        rec[names[f]] = s.length == 8 ? '${s.substring(0, 4)}-${s.substring(4, 6)}-${s.substring(6, 8)}' : (s.isEmpty ? null : s);
      } else {
        // C وأي نوع تاني نعامله كنص
        var end = chunk.length;
        while (end > 0 && (chunk[end - 1] == 0x20 || chunk[end - 1] == 0)) {
          end--;
        }
        final c2 = chunk.sublist(0, end);
        final s = (useEnc == TextEnc.cp1256 ? decodeCp1256(c2) : utf8.decode(c2, allowMalformed: true)).trim();
        rec[names[f]] = s.isEmpty ? null : s;
      }
    }
    records.add(rec);
  }
  return DbfTable(names, records);
}

// ───────────────── كتابة ─────────────────

class _FieldSpec {
  final String srcName;
  final List<int> nameBytes;
  final String type; // C | N | L
  final int length;
  final int decimals;
  _FieldSpec(this.srcName, this.nameBytes, this.type, this.length, this.decimals);
}

List<int> _truncateBytes(String s, int maxBytes, TextEnc enc) {
  final out = <int>[];
  for (final r in s.runes) {
    final b = encodeText(String.fromCharCode(r), enc);
    if (out.length + b.length > maxBytes) break;
    out.addAll(b);
  }
  return out;
}

String _sanitizeName(String n) {
  final s = n.trim().replaceAll(RegExp(r'[\s\-./\\()\[\]{}:;,]+'), '_');
  return s.isEmpty ? 'FIELD' : s;
}

String _numRepr(num v, int dec) => dec == 0 && v == v.roundToDouble() ? v.round().toString() : v.toStringAsFixed(dec);

int _decimalsOf(num v) {
  if (v is int || v == v.roundToDouble()) return 0;
  final s = v.toString();
  if (s.contains('e') || s.contains('E')) return 8;
  final i = s.indexOf('.');
  return i < 0 ? 0 : (s.length - i - 1).clamp(0, 8);
}

/// يكتب ملف DBF. الأسماء الطويلة بتتقص لـ 10 بايت (حد الصيغة)
/// ويرجع كمان خريطة [اسم أصلي → اسم في الملف].
(Uint8List, Map<String, String>) writeDbf(
  List<String> fields,
  List<Map<String, dynamic>> records, {
  TextEnc enc = TextEnc.utf8,
}) {
  final e = enc == TextEnc.cp1256 ? TextEnc.cp1256 : TextEnc.utf8;
  final specs = <_FieldSpec>[];
  final used = <String>{};
  final rename = <String, String>{};

  for (final f in fields.take(255)) {
    // نوع الحقل
    var allNum = true, allBool = true, any = false;
    var maxDec = 0;
    for (final r in records) {
      final v = r[f];
      if (v == null || (v is String && v.trim().isEmpty)) continue;
      any = true;
      if (v is! bool) allBool = false;
      if (v is! num) allNum = false;
      if (v is num) {
        if (v.isNaN || v.isInfinite) allNum = false;
        final d = _decimalsOf(v);
        if (d > maxDec) maxDec = d;
      }
    }
    String type;
    int len, dec = 0;
    if (any && allBool) {
      type = 'L';
      len = 1;
    } else if (any && allNum) {
      type = 'N';
      dec = maxDec;
      var w = 1;
      for (final r in records) {
        final v = r[f];
        if (v is num) {
          final l = _numRepr(v, dec).length;
          if (l > w) w = l;
        }
      }
      len = w;
      if (len > 19) {
        // كبير جداً → نخليه نص
        type = 'C';
        dec = 0;
      }
    } else {
      type = 'C';
      len = 1;
    }
    if (type == 'C') {
      len = 1;
      for (final r in records) {
        final v = r[f];
        if (v == null) continue;
        final b = encodeText(v.toString(), e).length;
        if (b > len) len = b;
      }
      if (len > 254) len = 254;
    }

    // اسم الحقل (10 بايت كحد أقصى، بدون تكرار)
    final base = _sanitizeName(f);
    var nb = _truncateBytes(base, 10, e);
    var key = String.fromCharCodes(nb);
    var i = 1;
    while (used.contains(key.toUpperCase())) {
      final suf = '_$i';
      nb = [..._truncateBytes(base, 10 - suf.length, e), ...suf.codeUnits];
      key = String.fromCharCodes(nb);
      i++;
    }
    used.add(key.toUpperCase());
    final finalName = e == TextEnc.cp1256 ? decodeCp1256(nb) : utf8.decode(nb, allowMalformed: true);
    rename[f] = finalName;
    specs.add(_FieldSpec(f, nb, type, len, dec));
  }

  final headerLen = 32 + 32 * specs.length + 1;
  final recLen = 1 + specs.fold<int>(0, (s, f) => s + f.length);
  final total = headerLen + recLen * records.length + 1;
  final out = Uint8List(total);
  final bd = ByteData.sublistView(out);
  final now = DateTime.now();
  out[0] = 0x03;
  out[1] = now.year - 1900;
  out[2] = now.month;
  out[3] = now.day;
  bd.setUint32(4, records.length, Endian.little);
  bd.setUint16(8, headerLen, Endian.little);
  bd.setUint16(10, recLen, Endian.little);
  out[29] = e == TextEnc.cp1256 ? 0x7E : 0x00; // Language Driver ID (Arabic Windows = 0x7E)

  var off = 32;
  for (final s in specs) {
    out.setRange(off, off + s.nameBytes.length, s.nameBytes);
    out[off + 11] = s.type.codeUnitAt(0);
    out[off + 16] = s.length;
    out[off + 17] = s.decimals;
    off += 32;
  }
  out[off] = 0x0D;
  off = headerLen;

  for (final r in records) {
    out[off++] = 0x20;
    for (final s in specs) {
      final v = r[s.srcName];
      final cell = List<int>.filled(s.length, 0x20);
      if (v != null) {
        if (s.type == 'N' && v is num) {
          final str = _numRepr(v, s.decimals);
          final b = ascii.encode(str);
          final start = s.length - b.length;
          for (var k = 0; k < b.length; k++) {
            cell[start + k] = b[k];
          }
        } else if (s.type == 'L' && v is bool) {
          cell[0] = v ? 0x54 : 0x46; // T / F
        } else if (s.type == 'C') {
          final b = _truncateBytes(v.toString(), s.length, e);
          for (var k = 0; k < b.length; k++) {
            cell[k] = b[k];
          }
        }
      }
      out.setRange(off, off + s.length, cell);
      off += s.length;
    }
  }
  out[off] = 0x1A;
  return (out, rename);
}
