import '../crs/crs.dart';
import '../models/geo.dart';
import '../utils/cp1256.dart';
import '../utils/geometry.dart';

// ═════════════════ قراءة DXF (ASCII) ═════════════════
// بيدعم: POINT, LINE, LWPOLYLINE, POLYLINE/VERTEX, TEXT, MTEXT
// الطبقات (Layers) بتتحفظ في حقل layer

GeoLayer readDxf(String name, List<int> bytes, {CrsDef? crs}) {
  final text = decodeText(bytes);
  final lines = text.split(RegExp(r'\r?\n'));
  final pairs = <(int, String)>[];
  var k = 0;
  while (k + 1 < lines.length) {
    final code = int.tryParse(lines[k].trim());
    if (code == null) {
      // ملف مش متناسق — نحاول نكمل سطر بسطر
      k++;
      continue;
    }
    pairs.add((code, lines[k + 1].trimRight()));
    k += 2;
  }

  final feats = <Feature>[];
  var inEntities = false;
  var i = 0;

  double? d(String s) => double.tryParse(s.trim());

  // بيقرا خصائص الكيان لحد أول (0, ...)
  List<(int, String)> entityBody() {
    final body = <(int, String)>[];
    i++;
    while (i < pairs.length && pairs[i].$1 != 0) {
      body.add(pairs[i]);
      i++;
    }
    return body;
  }

  String layerOf(List<(int, String)> b) {
    for (final p in b) {
      if (p.$1 == 8) return p.$2.trim();
    }
    return '0';
  }

  while (i < pairs.length) {
    final (code, val) = pairs[i];
    if (code == 0 && val == 'SECTION') {
      if (i + 1 < pairs.length && pairs[i + 1].$1 == 2) {
        inEntities = pairs[i + 1].$2.trim() == 'ENTITIES';
      }
      i++;
      continue;
    }
    if (code == 0 && val == 'ENDSEC') {
      inEntities = false;
      i++;
      continue;
    }
    if (!inEntities || code != 0) {
      i++;
      continue;
    }
    final type = val.trim();
    switch (type) {
      case 'POINT': {
        final b = entityBody();
        double? x, y, z;
        for (final p in b) {
          if (p.$1 == 10) x = d(p.$2);
          if (p.$1 == 20) y = d(p.$2);
          if (p.$1 == 30) z = d(p.$2);
        }
        if (x != null && y != null) {
          feats.add(Feature(GeomType.point, [
            [Coord(x, y, z == 0 ? null : z)]
          ], {'layer': layerOf(b)}));
        }
      }
      case 'TEXT':
      case 'MTEXT': {
        final b = entityBody();
        double? x, y;
        final sb = StringBuffer();
        for (final p in b) {
          if (p.$1 == 10) x = d(p.$2);
          if (p.$1 == 20) y = d(p.$2);
          if (p.$1 == 1 || p.$1 == 3) sb.write(p.$2);
        }
        var t = sb.toString().replaceAll(r'\P', ' ').replaceAll(RegExp(r'\\[A-Za-z][^;]*;'), '').replaceAll(RegExp(r'[{}]'), '');
        t = t.trim();
        if (x != null && y != null) {
          feats.add(Feature(GeomType.point, [
            [Coord(x, y)]
          ], {'layer': layerOf(b), 'text': t}));
        }
      }
      case 'LINE': {
        final b = entityBody();
        double? x1, y1, x2, y2;
        for (final p in b) {
          if (p.$1 == 10) x1 = d(p.$2);
          if (p.$1 == 20) y1 = d(p.$2);
          if (p.$1 == 11) x2 = d(p.$2);
          if (p.$1 == 21) y2 = d(p.$2);
        }
        if (x1 != null && y1 != null && x2 != null && y2 != null) {
          feats.add(Feature(GeomType.line, [
            [Coord(x1, y1), Coord(x2, y2)]
          ], {'layer': layerOf(b)}));
        }
      }
      case 'LWPOLYLINE': {
        final b = entityBody();
        var flags = 0;
        final pts = <Coord>[];
        double? cx;
        for (final p in b) {
          if (p.$1 == 70) flags = int.tryParse(p.$2.trim()) ?? 0;
          if (p.$1 == 10) cx = d(p.$2);
          if (p.$1 == 20 && cx != null) {
            final y = d(p.$2);
            if (y != null) pts.add(Coord(cx, y));
            cx = null;
          }
        }
        _addPoly(feats, pts, (flags & 1) == 1, layerOf(b));
      }
      case 'POLYLINE': {
        final head = entityBody();
        var flags = 0;
        for (final p in head) {
          if (p.$1 == 70) flags = int.tryParse(p.$2.trim()) ?? 0;
        }
        final pts = <Coord>[];
        while (i < pairs.length && pairs[i].$1 == 0 && pairs[i].$2.trim() == 'VERTEX') {
          final vb = entityBody();
          double? x, y, z;
          var vflags = 0;
          for (final p in vb) {
            if (p.$1 == 10) x = d(p.$2);
            if (p.$1 == 20) y = d(p.$2);
            if (p.$1 == 30) z = d(p.$2);
            if (p.$1 == 70) vflags = int.tryParse(p.$2.trim()) ?? 0;
          }
          // نتجاهل رؤوس الـ mesh/face
          if (x != null && y != null && (vflags & 128) == 0) pts.add(Coord(x, y, z == 0 ? null : z));
        }
        if (i < pairs.length && pairs[i].$2.trim() == 'SEQEND') entityBody();
        // 16/64 = mesh / polyface → نتجاهلهم
        if ((flags & (16 | 64)) == 0) _addPoly(feats, pts, (flags & 1) == 1, layerOf(head));
      }
      default:
        entityBody();
    }
  }

  final layer = GeoLayer(name: name, features: feats, crs: crs ?? Crs.guessFromCoords(feats.expand((f) => f.allCoords)));
  layer.crsGuessed = crs == null;
  return layer;
}

void _addPoly(List<Feature> feats, List<Coord> pts, bool closed, String layer) {
  if (pts.length < 2) return;
  final isClosed = closed || (pts.length > 3 && pts.first.sameXY(pts.last));
  if (isClosed && pts.length >= 3) {
    feats.add(Feature(GeomType.polygon, [closeRing(pts)], {'layer': layer}));
  } else {
    feats.add(Feature(GeomType.line, [pts], {'layer': layer}));
  }
}

// ═════════════════ كتابة DXF (R12 — بيفتح في أي AutoCAD) ═════════════════

String _layerName(String s) {
  final t = s.trim().replaceAll(RegExp(r'[<>/\\":;?*|=,`]'), '_');
  return t.isEmpty ? '0' : (t.length > 31 ? t.substring(0, 31) : t);
}

String _n(double v) => v.toStringAsFixed(4);

/// [labelField]: حقل يتكتب كنص جنب كل عنصر (رقم القطعة مثلاً)
List<int> writeDxf(GeoLayer layer, {String? labelField, double? textHeight}) {
  final sb = StringBuffer();
  void w(int code, Object v) => sb
    ..write('$code\r\n')
    ..write('$v\r\n');

  final bb = layer.bbox ?? [0, 0, 1, 1];
  final size = [(bb[2] - bb[0]).abs(), (bb[3] - bb[1]).abs()].reduce((a, b) => a > b ? a : b);
  final th = textHeight ?? (size <= 0 ? 1.0 : (size / 150).clamp(0.2, 50.0).toDouble());

  final layerNames = <String>{};
  String lyr(Feature f) {
    final a = f.attrs['layer'];
    final n = a != null && a.toString().trim().isNotEmpty
        ? _layerName(a.toString())
        : switch (f.type) {
            GeomType.point => 'POINTS',
            GeomType.line => 'LINES',
            GeomType.polygon => 'PARCELS',
          };
    layerNames.add(n);
    return n;
  }

  final ent = StringBuffer();
  void e(int code, Object v) => ent
    ..write('$code\r\n')
    ..write('$v\r\n');

  void poly(List<Coord> pts, bool closed, String l) {
    e(0, 'POLYLINE');
    e(8, l);
    e(66, 1);
    e(10, '0.0');
    e(20, '0.0');
    e(30, '0.0');
    e(70, closed ? 1 : 0);
    for (final p in pts) {
      e(0, 'VERTEX');
      e(8, l);
      e(10, _n(p.x));
      e(20, _n(p.y));
      e(30, _n(p.z ?? 0));
    }
    e(0, 'SEQEND');
    e(8, l);
  }

  for (final f in layer.features) {
    if (f.isEmpty) continue;
    final l = lyr(f);
    switch (f.type) {
      case GeomType.point:
        for (final p in f.parts) {
          if (p.isEmpty) continue;
          e(0, 'POINT');
          e(8, l);
          e(10, _n(p.first.x));
          e(20, _n(p.first.y));
          e(30, _n(p.first.z ?? 0));
        }
        break;
      case GeomType.line:
        for (final p in f.parts) {
          if (p.length >= 2) poly(p, false, l);
        }
        break;
      case GeomType.polygon:
        for (final r in f.parts) {
          if (r.length < 3) continue;
          // المضلع المقفول من غير تكرار آخر نقطة
          final pts = r.first.sameXY(r.last) ? r.sublist(0, r.length - 1) : r;
          poly(pts, true, l);
        }
        break;
    }
    final label = labelField == null ? null : f.attrs[labelField];
    if (label != null && label.toString().trim().isNotEmpty) {
      final lp = labelPoint(f);
      const tl = 'LABELS';
      layerNames.add(tl);
      e(0, 'TEXT');
      e(8, tl);
      e(10, _n(lp.x));
      e(20, _n(lp.y));
      e(30, '0.0');
      e(40, _n(th));
      e(1, label.toString().replaceAll(RegExp(r'[\r\n]+'), ' '));
      e(72, 1); // توسيط أفقي
      e(11, _n(lp.x));
      e(21, _n(lp.y));
      e(31, '0.0');
    }
  }

  // HEADER
  w(0, 'SECTION');
  w(2, 'HEADER');
  w(9, r'$ACADVER');
  w(1, 'AC1009');
  w(9, r'$DWGCODEPAGE');
  w(3, 'ANSI_1256');
  w(9, r'$INSUNITS');
  w(70, layer.crs.geographic ? 0 : 6); // 6 = متر
  w(9, r'$EXTMIN');
  w(10, _n(bb[0]));
  w(20, _n(bb[1]));
  w(30, '0.0');
  w(9, r'$EXTMAX');
  w(10, _n(bb[2]));
  w(20, _n(bb[3]));
  w(30, '0.0');
  w(0, 'ENDSEC');

  // TABLES (الطبقات بألوان مختلفة)
  w(0, 'SECTION');
  w(2, 'TABLES');
  w(0, 'TABLE');
  w(2, 'LAYER');
  w(70, layerNames.length + 1);
  var color = 1;
  for (final n in ['0', ...layerNames.where((x) => x != '0')]) {
    w(0, 'LAYER');
    w(2, n);
    w(70, 0);
    w(62, n == '0' ? 7 : color);
    w(6, 'CONTINUOUS');
    if (n != '0') color = color % 6 + 1;
  }
  w(0, 'ENDTAB');
  w(0, 'ENDSEC');

  w(0, 'SECTION');
  w(2, 'ENTITIES');
  sb.write(ent.toString());
  w(0, 'ENDSEC');
  w(0, 'EOF');

  // R12 = ANSI → النص العربي بترميز Windows-1256
  return encodeCp1256(sb.toString());
}
