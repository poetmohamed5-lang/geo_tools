import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'screens/area_screen.dart';
import 'screens/converter_screen.dart';
import 'screens/coord_screen.dart';
import 'screens/gps_screen.dart';
import 'screens/scanner_screen.dart';

void main() => runApp(const GeoToolsApp());

class GeoToolsApp extends StatelessWidget {
  const GeoToolsApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF0F766E); // أخضر مساحي
    return MaterialApp(
      title: 'أدوات المساح',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: seed),
        useMaterial3: true,
        inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder(), isDense: true),
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.dark),
        useMaterial3: true,
        inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder(), isDense: true),
      ),
      home: const HomeScreen(),
    );
  }
}

class _Tool {
  final String title;
  final String subtitle;
  final IconData icon;
  final Widget Function() page;
  const _Tool(this.title, this.subtitle, this.icon, this.page);
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  static final _tools = <_Tool>[
    _Tool('محوّل الملفات', 'Excel • KML • KMZ • Shapefile • GeoJSON • DXF • GPX — أي صيغة لأي صيغة',
        Icons.swap_horiz_rounded, () => const ConverterScreen()),
    _Tool('سكانر المستندات → PDF', 'تصوير ذكي بقص تلقائي وتحسين، أو صور من المعرض', Icons.document_scanner_rounded,
        () => const ScannerScreen()),
    _Tool('محوّل الإحداثيات', 'WGS84 ↔ UTM ↔ الأحزمة المصرية (أحمر/بنفسجي/أزرق) + درجات ودقائق',
        Icons.my_location_rounded, () => const CoordScreen()),
    _Tool('حساب المساحات', 'متر² وفدان/قيراط/سهم من ملف أو نقاط تدخلها بإيدك', Icons.square_foot_rounded,
        () => const AreaScreen()),
    _Tool('رفع نقاط GPS', 'سجّل نقاط من الموبايل في الموقع وصدّرها لأي صيغة', Icons.satellite_alt_rounded,
        () => const GpsScreen()),
  ];

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('أدوات المساح'), centerTitle: true),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: _tools.length,
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (context, i) {
          final t = _tools[i];
          return Card(
            elevation: 0,
            color: cs.surfaceContainerHighest,
            clipBehavior: Clip.antiAlias,
            child: InkWell(
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => t.page())),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(children: [
                  CircleAvatar(
                    radius: 26,
                    backgroundColor: cs.primary,
                    child: Icon(t.icon, color: cs.onPrimary, size: 28),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(t.title, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                      const SizedBox(height: 4),
                      Text(t.subtitle, style: Theme.of(context).textTheme.bodySmall),
                    ]),
                  ),
                  const Icon(Icons.chevron_left),
                ]),
              ),
            ),
          );
        },
      ),
    );
  }
}
