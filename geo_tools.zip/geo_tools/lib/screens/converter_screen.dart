import 'package:flutter/material.dart';

import '../formats/registry.dart';
import '../formats/table.dart';
import '../models/geo.dart';
import '../utils/cp1256.dart';
import '../utils/file_io.dart';
import '../utils/geometry.dart';
import '../widgets/common.dart';
import 'map_screen.dart';

class ConverterScreen extends StatefulWidget {
  const ConverterScreen({super.key});

  @override
  State<ConverterScreen> createState() => _ConverterScreenState();
}

class _ConverterScreenState extends State<ConverterScreen> {
  final List<GeoLayer> _layers = [];
  final List<String> _warnings = [];
  TextEnc _readEnc = TextEnc.auto;
  bool _busy = false;
  int _version = 0;

  Future<void> _pick() async {
    final files = await pickInputFiles();
    if (files.isEmpty) return;
    setState(() => _busy = true);
    try {
      final res = loadFiles(files, enc: _readEnc);
      final newLayers = [...res.layers];
      for (final t in res.tables) {
        if (!mounted) return;
        if (t.rows.isEmpty) {
          res.warnings.add('${t.name}: الشيت فاضي');
          continue;
        }
        if (isOwnExport(t)) {
          // ملف متصدّر من البرنامج: الأشكال بترجع تلقائي من غير أسئلة
          newLayers.add(tableToLayer(t, guessMapping(t))..crsGuessed = true);
          continue;
        }
        final l = await Navigator.push<GeoLayer>(context, MaterialPageRoute(builder: (_) => TableMappingScreen(table: t)));
        if (l != null) newLayers.add(l);
      }
      setState(() {
        _layers.addAll(newLayers.where((l) => l.features.isNotEmpty));
        _warnings
          ..clear()
          ..addAll(res.warnings);
        _version++;
      });
    } catch (e) {
      if (mounted) showMsg(context, 'خطأ: $e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String get _baseName => _layers.isEmpty ? 'output' : (_layers.length == 1 ? _layers.first.name : '${_layers.first.name}_merged');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('محوّل الملفات'),
        actions: [
          if (_layers.isNotEmpty)
            IconButton(
              tooltip: 'مسح الكل',
              onPressed: () => setState(() {
                _layers.clear();
                _warnings.clear();
                _version++;
              }),
              icon: const Icon(Icons.delete_sweep_outlined),
            ),
        ],
      ),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              FilledButton.icon(
                onPressed: _busy ? null : _pick,
                icon: _busy
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.upload_file_rounded),
                label: Text(_layers.isEmpty ? 'اختار ملف أو أكتر' : 'ضيف ملفات كمان'),
              ),
              const SizedBox(height: 8),
              const Text(
                'المدعوم: xlsx • csv • kml • kmz • geojson • dxf • gpx • Shapefile '
                '(اختار .shp و .dbf و .prj مع بعض، أو ملف zip فيهم)',
                style: TextStyle(fontSize: 12),
              ),
              const SizedBox(height: 8),
              LabeledDropdown<TextEnc>(
                value: _readEnc,
                label: 'ترميز العربي عند القراءة (DBF / CSV)',
                items: [for (final e in TextEnc.values) DropdownMenuItem(value: e, child: Text(e.labelAr))],
                onChanged: (v) => setState(() => _readEnc = v ?? TextEnc.auto),
              ),
            ]),
          ),
        ),
        for (final w in _warnings)
          Card(
            color: Colors.orange.withAlpha(40),
            child: ListTile(dense: true, leading: const Icon(Icons.warning_amber_rounded, color: Colors.orange), title: Text(w)),
          ),
        for (final l in _layers)
          LayerSummaryCard(
            key: ObjectKey(l),
            layer: l,
            onCrsChanged: (c) => setState(() {
              // تغيير نظام المصدر = إعادة تفسير الأرقام (مش تحويل)
              l.crs = c;
              l.crsGuessed = false;
              _version++;
            }),
            onRemove: () => setState(() {
              _layers.remove(l);
              _version++;
            }),
          ),
        if (_layers.isNotEmpty) ...[
          Row(children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MapScreen(layers: _layers))),
                icon: const Icon(Icons.map_outlined),
                label: const Text('معاينة على الخريطة'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () => _showAttributes(context),
                icon: const Icon(Icons.table_chart_outlined),
                label: const Text('البيانات والمساحات'),
              ),
            ),
          ]),
          const SizedBox(height: 8),
          ExportPanel(key: ValueKey(_version), layers: () => _layers, baseName: _baseName),
        ],
      ]),
    );
  }

  void _showAttributes(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => AttributesScreen(layers: _layers)),
    );
  }
}

/// تحديد أعمدة الإحداثيات في Excel/CSV
class TableMappingScreen extends StatefulWidget {
  final RawTable table;
  const TableMappingScreen({super.key, required this.table});

  @override
  State<TableMappingScreen> createState() => _TableMappingScreenState();
}

class _TableMappingScreenState extends State<TableMappingScreen> {
  late TableMapping m;

  @override
  void initState() {
    super.initState();
    m = guessMapping(widget.table);
    _groupHint = groupColumnCandidates(widget.table).firstOrNull;
  }

  int? _groupHint;

  int get _validCount {
    var n = 0;
    for (final r in widget.table.rows) {
      if (parseCoordValue(r[m.xCol]) != null && parseCoordValue(r[m.yCol]) != null) n++;
    }
    return n;
  }

  Widget _colDropdown(String label, int? value, ValueChanged<int?> onChanged, {bool optional = false}) {
    final h = widget.table.headers;
    return LabeledDropdown<int?>(
      value: value,
      label: label,
      items: [
        if (optional) const DropdownMenuItem<int?>(value: null, child: Text('— لا يوجد —')),
        for (var i = 0; i < h.length; i++) DropdownMenuItem<int?>(value: i, child: Text(h[i], overflow: TextOverflow.ellipsis)),
      ],
      onChanged: onChanged,
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.table;
    final fromOwnExport = m.typeCol != null;
    return Scaffold(
      appBar: AppBar(title: Text('أعمدة الإحداثيات — ${t.name}')),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        Text('${t.rows.length} صف • ${t.headers.length} عمود • $_validCount صف بإحداثيات سليمة'),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: _colDropdown('X / شرقيات / خط الطول', m.xCol, (v) => setState(() => m.xCol = v ?? m.xCol))),
          const SizedBox(width: 8),
          Expanded(child: _colDropdown('Y / شماليات / خط العرض', m.yCol, (v) => setState(() => m.yCol = v ?? m.yCol))),
        ]),
        const SizedBox(height: 12),
        _colDropdown('Z / منسوب (اختياري)', m.zCol, (v) => setState(() => m.zCol = v), optional: true),
        const SizedBox(height: 16),
        if (fromOwnExport)
          const Card(
            child: ListTile(
              leading: Icon(Icons.auto_awesome),
              title: Text('الملف ده متصدّر من البرنامج — الأشكال هترجع زي ما كانت تلقائي'),
            ),
          )
        else ...[
          const Text('نوع الشكل', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          SegmentedButton<GeomType>(
            segments: const [
              ButtonSegment(value: GeomType.point, label: Text('نقاط'), icon: Icon(Icons.place_outlined)),
              ButtonSegment(value: GeomType.line, label: Text('خط'), icon: Icon(Icons.timeline)),
              ButtonSegment(value: GeomType.polygon, label: Text('مضلع'), icon: Icon(Icons.pentagon_outlined)),
            ],
            selected: {m.geomType},
            onSelectionChanged: (s) => setState(() {
              m.geomType = s.first;
              // لو فيه عمود "رقم القطعة" نقترحه تلقائي للخطوط والمضلعات
              if (m.geomType != GeomType.point && m.groupCol == null) m.groupCol = _groupHint;
              if (m.geomType == GeomType.point) m.groupCol = null;
            }),
          ),
          const SizedBox(height: 12),
          if (m.geomType != GeomType.point || m.groupCol != null)
            _colDropdown(
              'عمود التجميع (رقم القطعة / الخط) — النقاط بنفس الرقم تبقى شكل واحد',
              m.groupCol,
              (v) => setState(() => m.groupCol = v),
              optional: true,
            ),
          if (m.geomType != GeomType.point && m.groupCol == null)
            const Padding(
              padding: EdgeInsets.only(top: 6),
              child: Text('من غير عمود تجميع: كل الصفوف هتبقى شكل واحد بالترتيب.', style: TextStyle(fontSize: 12)),
            ),
        ],
        const SizedBox(height: 12),
        CrsDropdown(value: m.crs, onChanged: (c) => setState(() => m.crs = c)),
        const SizedBox(height: 16),
        const Text('أول صفوف:', style: TextStyle(fontWeight: FontWeight.bold)),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: DataTable(
            columns: [for (final h in t.headers) DataColumn(label: Text(h))],
            rows: [
              for (final r in t.rows.take(5))
                DataRow(cells: [for (final v in r) DataCell(Text(v?.toString() ?? ''))]),
            ],
          ),
        ),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: _validCount == 0
              ? null
              : () {
                  final l = tableToLayer(t, m);
                  Navigator.pop(context, l);
                },
          icon: const Icon(Icons.check),
          label: const Text('تمام'),
        ),
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('تخطي الشيت ده')),
      ]),
    );
  }
}

/// عرض البيانات الوصفية والمساحات
class AttributesScreen extends StatelessWidget {
  final List<GeoLayer> layers;
  const AttributesScreen({super.key, required this.layers});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: layers.length,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('البيانات'),
          bottom: layers.length > 1 ? TabBar(isScrollable: true, tabs: [for (final l in layers) Tab(text: l.name)]) : null,
        ),
        body: TabBarView(children: [for (final l in layers) _LayerTable(layer: l)]),
      ),
    );
  }
}

class _LayerTable extends StatelessWidget {
  final GeoLayer layer;
  const _LayerTable({required this.layer});

  @override
  Widget build(BuildContext context) {
    final measurer = Measurer(layer.crs, sample: layer.features.expand((f) => f.allCoords).firstOrNull);
    final hasArea = layer.features.any((f) => f.type != GeomType.point);
    final rows = layer.features.take(500).toList();
    var total = 0.0;
    final ms = [for (final f in rows) measurer.of(f)];
    for (final m in ms) {
      total += m.area;
    }
    return ListView(padding: const EdgeInsets.all(8), children: [
      if (total > 0)
        Card(
          child: ListTile(
            leading: const Icon(Icons.square_foot),
            title: Text('إجمالي المساحة: ${fmtNum(total)} م²'),
            subtitle: Text(feddanText(total)),
          ),
        ),
      if (layer.features.length > 500) Text('بيعرض أول 500 عنصر من ${layer.features.length}'),
      SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          columns: [
            const DataColumn(label: Text('#')),
            const DataColumn(label: Text('النوع')),
            for (final f in layer.fields) DataColumn(label: Text(f)),
            if (hasArea) ...const [
              DataColumn(label: Text('المساحة م²')),
              DataColumn(label: Text('فدان/قيراط/سهم')),
              DataColumn(label: Text('الطول/المحيط م')),
            ],
          ],
          rows: [
            for (var i = 0; i < rows.length; i++)
              DataRow(cells: [
                DataCell(Text('${i + 1}')),
                DataCell(Text(rows[i].type.labelAr)),
                for (final f in layer.fields) DataCell(Text(rows[i].attrs[f]?.toString() ?? '')),
                if (hasArea) ...[
                  DataCell(Text(ms[i].area == 0 ? '' : fmtNum(ms[i].area))),
                  DataCell(Text(ms[i].area == 0 ? '' : feddanText(ms[i].area))),
                  DataCell(Text(fmtNum(ms[i].length > 0 ? ms[i].length : ms[i].perimeter))),
                ],
              ]),
          ],
        ),
      ),
    ]);
  }
}
