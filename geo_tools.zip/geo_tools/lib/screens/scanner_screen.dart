import 'dart:io';
import 'dart:isolate';
import 'dart:typed_data';

import 'package:cunning_document_scanner/cunning_document_scanner.dart';
import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/geo.dart';
import '../utils/file_io.dart';

enum ScanFilter { original, gray, document }

enum PageFit { a4, image }

enum Quality { high, medium, small }

class _Page {
  final Uint8List bytes;
  int quarterTurns = 0;
  _Page(this.bytes);
}

class ScannerScreen extends StatefulWidget {
  const ScannerScreen({super.key});

  @override
  State<ScannerScreen> createState() => _ScannerScreenState();
}

class _ScannerScreenState extends State<ScannerScreen> {
  final List<_Page> _pages = [];
  ScanFilter _filter = ScanFilter.original;
  PageFit _fit = PageFit.a4;
  Quality _quality = Quality.medium;
  final _name = TextEditingController(text: 'مستند_${DateTime.now().toIso8601String().substring(0, 10)}');
  bool _busy = false;
  OutFile? _result;

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Future<void> _scan() async {
    try {
      // سكانر ذكي: كشف حواف المستند تلقائي + قص + تعديل منظور
      final paths = await CunningDocumentScanner.getPictures();
      if (paths == null || paths.isEmpty) return;
      final pages = <_Page>[];
      for (final p in paths) {
        pages.add(_Page(await File(p).readAsBytes()));
      }
      setState(() {
        _pages.addAll(pages);
        _result = null;
      });
    } catch (e) {
      if (mounted) showMsg(context, 'السكانر مش متاح: $e', error: true);
    }
  }

  Future<void> _gallery() async {
    final files = await ImagePicker().pickMultiImage();
    if (files.isEmpty) return;
    final pages = <_Page>[];
    for (final f in files) {
      pages.add(_Page(await f.readAsBytes()));
    }
    setState(() {
      _pages.addAll(pages);
      _result = null;
    });
  }

  Future<void> _makePdf() async {
    if (_pages.isEmpty) return;
    setState(() => _busy = true);
    try {
      final images = [for (final p in _pages) p.bytes];
      final turns = [for (final p in _pages) p.quarterTurns];
      final filter = _filter.index;
      final fit = _fit.index;
      final q = _quality.index;
      final pdf = await _pdfInBackground(images, turns, filter, fit, q);
      final name = _name.text.trim().isEmpty ? 'scan' : _name.text.trim().replaceAll(RegExp(r'[\\/:*?"<>|]+'), '_');
      setState(() => _result = OutFile('$name.pdf', pdf));
    } catch (e) {
      if (mounted) showMsg(context, 'فشل إنشاء PDF: $e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('سكانر → PDF')),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        Row(children: [
          Expanded(
            child: FilledButton.icon(
              onPressed: _scan,
              icon: const Icon(Icons.document_scanner_outlined),
              label: const Text('مسح بالكاميرا'),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: OutlinedButton.icon(
              onPressed: _gallery,
              icon: const Icon(Icons.photo_library_outlined),
              label: const Text('صور من المعرض'),
            ),
          ),
        ]),
        const SizedBox(height: 6),
        const Text('السكانر بيكتشف حواف الورقة تلقائي ويعدّل الميل، وتقدر تمسح كذا صفحة ورا بعض.', style: TextStyle(fontSize: 12)),
        const SizedBox(height: 12),
        if (_pages.isEmpty)
          const Padding(
            padding: EdgeInsets.all(32),
            child: Center(child: Text('مفيش صفحات لسه')),
          )
        else
          ReorderableListView(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            onReorder: (a, b) => setState(() {
              if (b > a) b--;
              _pages.insert(b, _pages.removeAt(a));
              _result = null;
            }),
            children: [
              for (var i = 0; i < _pages.length; i++)
                Card(
                  key: ObjectKey(_pages[i]),
                  child: Padding(
                    padding: const EdgeInsets.all(6),
                    child: Row(children: [
                      RotatedBox(
                        quarterTurns: _pages[i].quarterTurns,
                        child: Image.memory(_pages[i].bytes, width: 70, height: 90, fit: BoxFit.cover, cacheWidth: 200),
                      ),
                      const SizedBox(width: 12),
                      Expanded(child: Text('صفحة ${i + 1}')),
                      IconButton(
                        tooltip: 'لف',
                        onPressed: () => setState(() {
                          _pages[i].quarterTurns = (_pages[i].quarterTurns + 1) % 4;
                          _result = null;
                        }),
                        icon: const Icon(Icons.rotate_right),
                      ),
                      IconButton(
                        tooltip: 'حذف',
                        onPressed: () => setState(() {
                          _pages.removeAt(i);
                          _result = null;
                        }),
                        icon: const Icon(Icons.delete_outline),
                      ),
                      const Icon(Icons.drag_handle),
                    ]),
                  ),
                ),
            ],
          ),
        if (_pages.isNotEmpty) ...[
          const SizedBox(height: 12),
          const Text('الفلتر', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          SegmentedButton<ScanFilter>(
            segments: const [
              ButtonSegment(value: ScanFilter.original, label: Text('أصلي')),
              ButtonSegment(value: ScanFilter.gray, label: Text('رمادي')),
              ButtonSegment(value: ScanFilter.document, label: Text('مستند واضح')),
            ],
            selected: {_filter},
            onSelectionChanged: (s) => setState(() {
              _filter = s.first;
              _result = null;
            }),
          ),
          const SizedBox(height: 12),
          const Text('مقاس الصفحة', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          SegmentedButton<PageFit>(
            segments: const [
              ButtonSegment(value: PageFit.a4, label: Text('A4')),
              ButtonSegment(value: PageFit.image, label: Text('مقاس الصورة')),
            ],
            selected: {_fit},
            onSelectionChanged: (s) => setState(() {
              _fit = s.first;
              _result = null;
            }),
          ),
          const SizedBox(height: 12),
          const Text('الجودة / الحجم', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          SegmentedButton<Quality>(
            segments: const [
              ButtonSegment(value: Quality.high, label: Text('عالية')),
              ButtonSegment(value: Quality.medium, label: Text('متوسطة')),
              ButtonSegment(value: Quality.small, label: Text('مضغوط')),
            ],
            selected: {_quality},
            onSelectionChanged: (s) => setState(() {
              _quality = s.first;
              _result = null;
            }),
          ),
          const SizedBox(height: 12),
          TextField(controller: _name, decoration: const InputDecoration(labelText: 'اسم الملف')),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _busy ? null : _makePdf,
            icon: _busy
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.picture_as_pdf_outlined),
            label: Text('اعمل PDF (${_pages.length} صفحة)'),
          ),
          if (_result != null) ...[const SizedBox(height: 12), OutputActions(file: _result!)],
        ],
      ]),
    );
  }
}

/// بيشتغل في Isolate منفصل عشان الواجهة ماتهنجش
/// (دالة top-level عشان الـ closure مايمسكش الـ State)
Future<Uint8List> _pdfInBackground(List<Uint8List> images, List<int> turns, int filter, int fit, int quality) =>
    Isolate.run(() => buildPdf(images, turns, filter, fit, quality));

Future<Uint8List> buildPdf(List<Uint8List> images, List<int> turns, int filter, int fit, int quality) async {
  final maxDim = [2400, 1800, 1200][quality];
  final jpgQ = [90, 78, 62][quality];
  final doc = pw.Document(title: 'Scan', creator: 'GeoTools');
  for (var i = 0; i < images.length; i++) {
    var im = img.decodeImage(images[i]);
    if (im == null) continue;
    im = img.bakeOrientation(im);
    if (turns[i] != 0) im = img.copyRotate(im, angle: 90 * turns[i]);
    final longSide = im.width > im.height ? im.width : im.height;
    if (longSide > maxDim) {
      im = im.width >= im.height ? img.copyResize(im, width: maxDim) : img.copyResize(im, height: maxDim);
    }
    if (filter == ScanFilter.gray.index) {
      im = img.grayscale(im);
    } else if (filter == ScanFilter.document.index) {
      im = img.grayscale(im);
      im = img.adjustColor(im, contrast: 1.6, brightness: 1.12);
    }
    final jpg = img.encodeJpg(im, quality: jpgQ);
    final mem = pw.MemoryImage(jpg);
    final landscape = im.width > im.height;

    if (fit == PageFit.a4.index) {
      doc.addPage(pw.Page(
        pageFormat: landscape ? PdfPageFormat.a4.landscape : PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(14),
        build: (_) => pw.Center(child: pw.Image(mem, fit: pw.BoxFit.contain)),
      ));
    } else {
      const w = 595.0; // عرض A4 بالنقاط
      final h = w * im.height / im.width;
      doc.addPage(pw.Page(
        pageFormat: PdfPageFormat(w, h),
        margin: pw.EdgeInsets.zero,
        build: (_) => pw.Image(mem, fit: pw.BoxFit.fill),
      ));
    }
  }
  return doc.save();
}
