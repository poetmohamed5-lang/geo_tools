import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../crs/crs.dart';
import '../models/geo.dart';
import '../utils/file_io.dart';
import '../utils/geometry.dart';
import '../utils/location.dart';
import '../widgets/common.dart';

class CoordScreen extends StatefulWidget {
  const CoordScreen({super.key});

  @override
  State<CoordScreen> createState() => _CoordScreenState();
}

class _CoordScreenState extends State<CoordScreen> {
  CrsDef _from = Crs.wgs84;
  CrsDef _to = Crs.utm36;
  final _x = TextEditingController();
  final _y = TextEditingController();
  final _batch = TextEditingController();
  String? _out;
  String? _batchOut;

  @override
  void dispose() {
    _x.dispose();
    _y.dispose();
    _batch.dispose();
    super.dispose();
  }

  String _fmt(Coord c, CrsDef crs) {
    if (crs.geographic) {
      return 'خط العرض: ${c.y.toStringAsFixed(8)}\n'
          'خط الطول: ${c.x.toStringAsFixed(8)}\n'
          '${toDms(c.y, isLat: true)}   ${toDms(c.x, isLat: false)}';
    }
    return 'X (شرقيات): ${c.x.toStringAsFixed(3)}\nY (شماليات): ${c.y.toStringAsFixed(3)}';
  }

  void _convert() {
    final x = parseCoordValue(_x.text);
    final y = parseCoordValue(_y.text);
    if (x == null || y == null) {
      showMsg(context, 'اكتب الإحداثيين صح', error: true);
      return;
    }
    try {
      final r = CrsTransformer(_from, _to).apply(Coord(x, y));
      setState(() => _out = _fmt(r, _to));
    } catch (e) {
      showMsg(context, 'خطأ في التحويل: $e', error: true);
    }
  }

  void _convertBatch() {
    final t = CrsTransformer(_from, _to);
    final out = StringBuffer();
    var bad = 0;
    for (final line in _batch.text.split(RegExp(r'\r?\n'))) {
      if (line.trim().isEmpty) continue;
      final parts = line.split(RegExp(r'[,;\t]+|\s{2,}')).map((s) => s.trim()).where((s) => s.isNotEmpty).toList();
      // آخر عمودين = X و Y ، اللي قبلهم (لو موجود) اسم النقطة
      if (parts.length < 2) {
        bad++;
        continue;
      }
      final x = parseCoordValue(parts[parts.length - 2]);
      final y = parseCoordValue(parts[parts.length - 1]);
      if (x == null || y == null) {
        bad++;
        continue;
      }
      final r = t.apply(Coord(x, y));
      final label = parts.length > 2 ? '${parts.sublist(0, parts.length - 2).join(' ')},' : '';
      final dec = _to.geographic ? 8 : 3;
      out.writeln('$label${r.x.toStringAsFixed(dec)},${r.y.toStringAsFixed(dec)}');
    }
    setState(() => _batchOut = out.toString().trim());
    if (bad > 0) showMsg(context, '$bad سطر متقراش');
  }

  Future<void> _useGps() async {
    try {
      final p = await getCurrentPosition();
      final c = CrsTransformer(Crs.wgs84, _from).apply(Coord(p.longitude, p.latitude));
      setState(() {
        _x.text = _from.geographic ? c.x.toStringAsFixed(8) : c.x.toStringAsFixed(3);
        _y.text = _from.geographic ? c.y.toStringAsFixed(8) : c.y.toStringAsFixed(3);
      });
      if (mounted) showMsg(context, 'دقة الموقع ± ${p.accuracy.toStringAsFixed(1)} م');
      _convert();
    } catch (e) {
      if (mounted) showMsg(context, '$e', error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('محوّل الإحداثيات')),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        CrsDropdown(label: 'من', value: _from, onChanged: (c) => setState(() => _from = c)),
        Center(
          child: IconButton(
            tooltip: 'بدّل',
            onPressed: () => setState(() {
              final t = _from;
              _from = _to;
              _to = t;
            }),
            icon: const Icon(Icons.swap_vert_rounded),
          ),
        ),
        CrsDropdown(label: 'إلى', value: _to, onChanged: (c) => setState(() => _to = c)),
        const SizedBox(height: 16),
        Row(children: [
          Expanded(
            child: TextField(
              controller: _x,
              textDirection: TextDirection.ltr,
              decoration: InputDecoration(labelText: _from.geographic ? 'خط الطول (Lon)' : 'X شرقيات'),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: TextField(
              controller: _y,
              textDirection: TextDirection.ltr,
              decoration: InputDecoration(labelText: _from.geographic ? 'خط العرض (Lat)' : 'Y شماليات'),
            ),
          ),
        ]),
        const SizedBox(height: 4),
        const Text('تقدر تكتب درجات ودقائق وثواني زي: 30°02\'45.3"N', style: TextStyle(fontSize: 12)),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: FilledButton.icon(onPressed: _convert, icon: const Icon(Icons.sync_alt), label: const Text('حوّل'))),
          const SizedBox(width: 8),
          Expanded(
            child: OutlinedButton.icon(onPressed: _useGps, icon: const Icon(Icons.gps_fixed), label: const Text('موقعي الحالي')),
          ),
        ]),
        if (_out != null)
          Card(
            margin: const EdgeInsets.only(top: 12),
            child: ListTile(
              title: SelectableText(_out!, textDirection: TextDirection.ltr),
              trailing: IconButton(
                icon: const Icon(Icons.copy),
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: _out!));
                  showMsg(context, 'اتنسخ');
                },
              ),
            ),
          ),
        const SizedBox(height: 20),
        ExpansionTile(
          title: const Text('تحويل مجموعة نقاط مرة واحدة'),
          childrenPadding: const EdgeInsets.all(8),
          children: [
            TextField(
              controller: _batch,
              maxLines: 8,
              textDirection: TextDirection.ltr,
              decoration: const InputDecoration(hintText: 'P1, 31.2357, 30.0444\nP2, 31.2400, 30.0500', labelText: 'سطر لكل نقطة: (اسم اختياري) , X , Y'),
            ),
            const SizedBox(height: 8),
            FilledButton(onPressed: _convertBatch, child: const Text('حوّل الكل')),
            if (_batchOut != null) ...[
              const SizedBox(height: 8),
              SelectableText(_batchOut!, textDirection: TextDirection.ltr),
              TextButton.icon(
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: _batchOut!));
                  showMsg(context, 'اتنسخ');
                },
                icon: const Icon(Icons.copy),
                label: const Text('نسخ النتيجة'),
              ),
            ],
          ],
        ),
        const SizedBox(height: 12),
        const Text(
          'ملحوظة: التحويل من/إلى الأحزمة المصرية (داتم 1907) بمعاملات EPSG العامة ودقتها حوالي 4 متر. '
          'للأعمال اللي محتاجة دقة سنتيمترات استخدم معاملات تحويل محلية.',
          style: TextStyle(fontSize: 12),
        ),
      ]),
    );
  }
}
