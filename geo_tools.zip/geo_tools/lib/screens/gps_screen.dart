import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';

import '../crs/crs.dart';
import '../models/geo.dart';
import '../utils/file_io.dart';
import '../utils/geometry.dart';
import '../utils/location.dart';
import '../widgets/common.dart';
import 'map_screen.dart';

class _GpsPoint {
  String name;
  final double lat, lon;
  final double? alt;
  final double accuracy;
  final String time;
  _GpsPoint(this.name, this.lat, this.lon, this.alt, this.accuracy, this.time);

  Map<String, dynamic> toJson() => {'name': name, 'lat': lat, 'lon': lon, 'alt': alt, 'acc': accuracy, 'time': time};

  static _GpsPoint fromJson(Map<String, dynamic> j) => _GpsPoint(
        j['name'] as String,
        (j['lat'] as num).toDouble(),
        (j['lon'] as num).toDouble(),
        (j['alt'] as num?)?.toDouble(),
        (j['acc'] as num).toDouble(),
        j['time'] as String,
      );
}

class GpsScreen extends StatefulWidget {
  const GpsScreen({super.key});

  @override
  State<GpsScreen> createState() => _GpsScreenState();
}

class _GpsScreenState extends State<GpsScreen> {
  final List<_GpsPoint> _points = [];
  GeomType _mode = GeomType.point;
  bool _busy = false;
  int _version = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<File> get _file async => File('${(await getApplicationDocumentsDirectory()).path}/gps_points.json');

  Future<void> _load() async {
    try {
      final f = await _file;
      if (await f.exists()) {
        final list = jsonDecode(await f.readAsString()) as List;
        setState(() {
          _points.addAll(list.map((e) => _GpsPoint.fromJson((e as Map).cast<String, dynamic>())));
          _version++;
        });
      }
    } catch (_) {}
  }

  Future<void> _save() async {
    try {
      await (await _file).writeAsString(jsonEncode([for (final p in _points) p.toJson()]));
    } catch (_) {}
  }

  Future<void> _capture() async {
    setState(() => _busy = true);
    try {
      final pos = await getCurrentPosition();
      final p = _GpsPoint(
        'P${_points.length + 1}',
        pos.latitude,
        pos.longitude,
        pos.altitude == 0 ? null : pos.altitude,
        pos.accuracy,
        DateTime.now().toIso8601String().substring(0, 19),
      );
      setState(() {
        _points.add(p);
        _version++;
      });
      await _save();
      if (mounted) showMsg(context, 'اتسجلت ${p.name} — دقة ± ${pos.accuracy.toStringAsFixed(1)} م');
    } catch (e) {
      if (mounted) showMsg(context, '$e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _rename(_GpsPoint p) async {
    final c = TextEditingController(text: p.name);
    final v = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('اسم النقطة'),
        content: TextField(controller: c, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text), child: const Text('حفظ')),
        ],
      ),
    );
    if (v != null && v.trim().isNotEmpty) {
      setState(() {
        p.name = v.trim();
        _version++;
      });
      await _save();
    }
  }

  GeoLayer _layer() {
    final coords = [for (final p in _points) Coord(p.lon, p.lat, p.alt)];
    List<Feature> feats;
    if (_mode == GeomType.point || _points.length < (_mode == GeomType.polygon ? 3 : 2)) {
      feats = [
        for (final p in _points)
          Feature(GeomType.point, [
            [Coord(p.lon, p.lat, p.alt)]
          ], {'name': p.name, 'accuracy_m': double.parse(p.accuracy.toStringAsFixed(2)), 'time': p.time})
      ];
    } else {
      feats = [
        Feature(_mode, [_mode == GeomType.polygon ? closeRing(coords) : coords], {'name': 'GPS_${_mode.key}'})
      ];
    }
    return GeoLayer(name: 'gps_${DateTime.now().toIso8601String().substring(0, 10)}', features: feats, crs: Crs.wgs84);
  }

  @override
  Widget build(BuildContext context) {
    final layer = _layer();
    Measure? m;
    if (_mode == GeomType.polygon && _points.length >= 3) m = Measurer(Crs.wgs84, sample: Coord(_points.first.lon, _points.first.lat)).of(layer.features.first);
    if (_mode == GeomType.line && _points.length >= 2) m = Measurer(Crs.wgs84, sample: Coord(_points.first.lon, _points.first.lat)).of(layer.features.first);

    return Scaffold(
      appBar: AppBar(
        title: const Text('رفع نقاط GPS'),
        actions: [
          if (_points.isNotEmpty)
            IconButton(
              tooltip: 'مسح الكل',
              icon: const Icon(Icons.delete_sweep_outlined),
              onPressed: () async {
                final ok = await showDialog<bool>(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    title: const Text('مسح كل النقاط؟'),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('لا')),
                      FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('امسح')),
                    ],
                  ),
                );
                if (ok == true) {
                  setState(() {
                    _points.clear();
                    _version++;
                  });
                  await _save();
                }
              },
            ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _busy ? null : _capture,
        icon: _busy
            ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
            : const Icon(Icons.add_location_alt_rounded),
        label: const Text('سجّل نقطة'),
      ),
      body: ListView(padding: const EdgeInsets.fromLTRB(12, 12, 12, 90), children: [
        const Text('دقة GPS الموبايل عادةً من 3 لـ 10 متر — مناسب للاستكشاف مش للرفع المساحي الدقيق.', style: TextStyle(fontSize: 12)),
        const SizedBox(height: 8),
        SegmentedButton<GeomType>(
          segments: const [
            ButtonSegment(value: GeomType.point, label: Text('نقاط')),
            ButtonSegment(value: GeomType.line, label: Text('خط')),
            ButtonSegment(value: GeomType.polygon, label: Text('مضلع')),
          ],
          selected: {_mode},
          onSelectionChanged: (s) => setState(() {
            _mode = s.first;
            _version++;
          }),
        ),
        if (m != null)
          Card(
            child: ListTile(
              leading: const Icon(Icons.square_foot),
              title: Text(_mode == GeomType.polygon ? 'المساحة: ${fmtNum(m.area)} م² — ${feddanText(m.area)}' : 'الطول: ${fmtNum(m.length)} م'),
              subtitle: _mode == GeomType.polygon ? Text('المحيط: ${fmtNum(m.perimeter)} م') : null,
            ),
          ),
        for (var i = 0; i < _points.length; i++)
          Card(
            child: ListTile(
              dense: true,
              leading: CircleAvatar(child: Text('${i + 1}')),
              title: Text(_points[i].name),
              subtitle: Text(
                '${_points[i].lat.toStringAsFixed(7)}, ${_points[i].lon.toStringAsFixed(7)}   ± ${_points[i].accuracy.toStringAsFixed(1)} م',
                textDirection: TextDirection.ltr,
              ),
              onTap: () => _rename(_points[i]),
              trailing: IconButton(
                icon: const Icon(Icons.delete_outline),
                onPressed: () async {
                  setState(() {
                    _points.removeAt(i);
                    _version++;
                  });
                  await _save();
                },
              ),
            ),
          ),
        if (_points.isNotEmpty) ...[
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MapScreen(layers: [layer]))),
            icon: const Icon(Icons.map_outlined),
            label: const Text('على الخريطة'),
          ),
          const SizedBox(height: 8),
          ExportPanel(key: ValueKey(_version), layers: _layer, baseName: layer.name),
        ],
      ]),
    );
  }
}
