import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../crs/crs.dart';
import '../formats/registry.dart';
import '../models/geo.dart';
import '../utils/file_io.dart';
import '../utils/geometry.dart';
import '../widgets/common.dart';
import 'converter_screen.dart';
import 'map_screen.dart';

class AreaScreen extends StatefulWidget {
  const AreaScreen({super.key});

  @override
  State<AreaScreen> createState() => _AreaScreenState();
}

class _AreaScreenState extends State<AreaScreen> {
  CrsDef _crs = Crs.utm36;
  final _pts = TextEditingController();
  Feature? _feature;
  Measure? _measure;
  List<double> _sides = [];

  @override
  void dispose() {
    _pts.dispose();
    super.dispose();
  }

  Future<void> _fromFile() async {
    final files = await pickInputFiles();
    if (files.isEmpty || !mounted) return;
    final res = loadFiles(files);
    final layers = [...res.layers];
    for (final t in res.tables) {
      if (!mounted) return;
      final l = await Navigator.push<GeoLayer>(context, MaterialPageRoute(builder: (_) => TableMappingScreen(table: t)));
      if (l != null) layers.add(l);
    }
    if (!mounted) return;
    for (final w in res.warnings) {
      showMsg(context, w);
    }
    if (layers.isEmpty) return;
    Navigator.push(context, MaterialPageRoute(builder: (_) => AttributesScreen(layers: layers)));
  }

  void _calc() {
    final pts = <Coord>[];
    for (final line in _pts.text.split(RegExp(r'\r?\n'))) {
      final nums = line
          .split(RegExp(r'[,;\t ]+'))
          .map((s) => parseCoordValue(s))
          .whereType<double>()
          .toList();
      if (nums.length >= 2) pts.add(Coord(nums[nums.length - 2], nums[nums.length - 1]));
    }
    if (pts.length < 3) {
      showMsg(context, 'محتاج 3 نقاط على الأقل', error: true);
      return;
    }
    final f = Feature(GeomType.polygon, [closeRing(pts)], {'name': 'قطعة'});
    final m = Measurer(_crs, sample: pts.first).of(f);
    // أطوال الأضلاع بالمتر
    final metric = _crs.geographic ? [for (final p in closeRing(pts)) CrsTransformer(_crs, Crs.utmForLon(pts.first.x)).apply(p)] : closeRing(pts);
    final sides = <double>[];
    for (var i = 1; i < metric.length; i++) {
      sides.add(math.sqrt(math.pow(metric[i].x - metric[i - 1].x, 2) + math.pow(metric[i].y - metric[i - 1].y, 2)));
    }
    setState(() {
      _feature = f;
      _measure = m;
      _sides = sides;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('حساب المساحات')),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        Card(
          child: ListTile(
            leading: const Icon(Icons.upload_file),
            title: const Text('من ملف'),
            subtitle: const Text('Shapefile / KML / KMZ / DXF / Excel … مساحة كل قطعة والإجمالي'),
            onTap: _fromFile,
          ),
        ),
        const SizedBox(height: 12),
        const Text('أو اكتب إحداثيات أركان القطعة بالترتيب:', style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        CrsDropdown(value: _crs, onChanged: (c) => setState(() => _crs = c)),
        const SizedBox(height: 8),
        TextField(
          controller: _pts,
          maxLines: 8,
          textDirection: TextDirection.ltr,
          decoration: const InputDecoration(
            labelText: 'سطر لكل ركن: X , Y',
            hintText: '325410.25, 3329870.10\n325455.80, 3329872.40\n325452.10, 3329820.65\n325408.90, 3329818.30',
          ),
        ),
        const SizedBox(height: 8),
        FilledButton.icon(onPressed: _calc, icon: const Icon(Icons.calculate_outlined), label: const Text('احسب')),
        if (_measure != null) ...[
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('المساحة: ${fmtNum(_measure!.area)} م²', style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 4),
                Text(feddanText(_measure!.area), style: Theme.of(context).textTheme.titleMedium),
                Text('= ${(_measure!.area / sqmPerFeddan).toStringAsFixed(4)} فدان'),
                const SizedBox(height: 4),
                Text('المحيط: ${fmtNum(_measure!.perimeter)} م'),
                const Divider(),
                const Text('أطوال الأضلاع:', style: TextStyle(fontWeight: FontWeight.bold)),
                for (var i = 0; i < _sides.length; i++)
                  Text('ضلع ${i + 1} → ${i + 2 > _sides.length ? 1 : i + 2}:  ${fmtNum(_sides[i])} م'),
              ]),
            ),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => MapScreen(layers: [GeoLayer(name: 'القطعة', features: [_feature!], crs: _crs)])),
            ),
            icon: const Icon(Icons.map_outlined),
            label: const Text('شوفها على الخريطة'),
          ),
          const SizedBox(height: 8),
          ExportPanel(
            key: ObjectKey(_feature),
            layers: () => [GeoLayer(name: 'parcel', features: [_feature!], crs: _crs)],
            baseName: 'parcel',
          ),
        ],
      ]),
    );
  }
}
