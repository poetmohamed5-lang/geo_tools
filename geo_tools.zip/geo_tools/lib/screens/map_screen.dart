import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart' hide Crs;
import 'package:latlong2/latlong.dart';

import '../crs/crs.dart';
import '../models/geo.dart';
import '../utils/geometry.dart';

class MapScreen extends StatefulWidget {
  final List<GeoLayer> layers;
  const MapScreen({super.key, required this.layers});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  bool _satellite = true;

  static const _colors = [Colors.red, Colors.blue, Colors.amber, Colors.purple, Colors.green, Colors.cyan, Colors.orange];

  @override
  Widget build(BuildContext context) {
    final polygons = <Polygon>[];
    final polylines = <Polyline>[];
    final markers = <Marker>[];
    final allPts = <LatLng>[];

    LatLng ll(Coord c) => LatLng(c.y.clamp(-85.0, 85.0).toDouble(), c.x.clamp(-180.0, 180.0).toDouble());

    for (var li = 0; li < widget.layers.length; li++) {
      final color = _colors[li % _colors.length];
      final layer = widget.layers[li].transformedTo(Crs.wgs84);
      for (final f in layer.features) {
        switch (f.type) {
          case GeomType.point:
            for (final p in f.parts) {
              if (p.isEmpty) continue;
              final pt = ll(p.first);
              allPts.add(pt);
              markers.add(Marker(
                point: pt,
                width: 18,
                height: 18,
                child: Container(
                  decoration: BoxDecoration(color: color, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2)),
                ),
              ));
            }
            break;
          case GeomType.line:
            for (final p in f.parts) {
              final pts = [for (final c in p) ll(c)];
              allPts.addAll(pts);
              if (pts.length >= 2) polylines.add(Polyline(points: pts, color: color, strokeWidth: 3));
            }
            break;
          case GeomType.polygon:
            for (final poly in groupRings(f.parts)) {
              final outer = [for (final c in poly.first) ll(c)];
              allPts.addAll(outer);
              polygons.add(Polygon(
                points: outer,
                holePointsList: [
                  for (final h in poly.skip(1)) [for (final c in h) ll(c)]
                ],
                color: color.withAlpha(70),
                borderColor: color,
                borderStrokeWidth: 2,
              ));
            }
            break;
        }
      }
    }

    final fit = allPts.isEmpty
        ? null
        : CameraFit.bounds(bounds: LatLngBounds.fromPoints(allPts), padding: const EdgeInsets.all(40), maxZoom: 18);

    return Scaffold(
      appBar: AppBar(
        title: const Text('معاينة'),
        actions: [
          IconButton(
            tooltip: _satellite ? 'خريطة عادية' : 'قمر صناعي',
            onPressed: () => setState(() => _satellite = !_satellite),
            icon: Icon(_satellite ? Icons.map_outlined : Icons.satellite_alt_outlined),
          ),
        ],
      ),
      body: Stack(children: [
        FlutterMap(
          options: MapOptions(
            initialCenter: const LatLng(30.05, 31.23),
            initialZoom: 6,
            initialCameraFit: fit,
            maxZoom: 20,
          ),
          children: [
            TileLayer(
              urlTemplate: _satellite
                  ? 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'
                  : 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
              userAgentPackageName: 'com.yallabanking.geo_tools',
              maxNativeZoom: 19,
            ),
            PolygonLayer(polygons: polygons),
            PolylineLayer(polylines: polylines),
            MarkerLayer(markers: markers),
          ],
        ),
        Positioned(
          bottom: 8,
          left: 8,
          right: 8,
          child: Card(
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Wrap(spacing: 12, runSpacing: 4, children: [
                for (var i = 0; i < widget.layers.length; i++)
                  Row(mainAxisSize: MainAxisSize.min, children: [
                    Container(width: 12, height: 12, color: _colors[i % _colors.length]),
                    const SizedBox(width: 4),
                    Text(widget.layers[i].name, style: const TextStyle(fontSize: 12)),
                  ]),
                Text(_satellite ? '© Esri' : '© OpenStreetMap', style: const TextStyle(fontSize: 10)),
              ]),
            ),
          ),
        ),
      ]),
    );
  }
}
