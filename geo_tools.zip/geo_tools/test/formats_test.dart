// اختبارات التحويل — شغّلها بـ:  flutter test
import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:geo_tools/crs/crs.dart';
import 'package:geo_tools/formats/dbf.dart';
import 'package:geo_tools/formats/dxf.dart';
import 'package:geo_tools/formats/geojson.dart';
import 'package:geo_tools/formats/kml.dart';
import 'package:geo_tools/formats/registry.dart';
import 'package:geo_tools/formats/shapefile.dart';
import 'package:geo_tools/formats/table.dart';
import 'package:geo_tools/models/geo.dart';
import 'package:geo_tools/utils/cp1256.dart';
import 'package:geo_tools/utils/geometry.dart';

GeoLayer _parcel() => GeoLayer(name: 'test', crs: Crs.utm36, features: [
      Feature(GeomType.polygon, [
        [
          const Coord(330000, 3325000),
          const Coord(330100, 3325000),
          const Coord(330100, 3325100),
          const Coord(330000, 3325100),
          const Coord(330000, 3325000),
        ]
      ], {
        'الاسم': 'قطعة ١',
        'رقم': 5,
        'قيمة': 12.75,
      }),
      Feature(GeomType.point, [
        [const Coord(330050, 3325050)]
      ], {
        'الاسم': 'نقطة',
        'رقم': 6,
        'قيمة': null,
      }),
    ]);

void main() {
  test('cp1256 encode/decode', () {
    const s = 'مساحة القطعة 25';
    expect(decodeCp1256(encodeCp1256(s)), s);
  });

  test('DBF عربي UTF-8 و 1256', () {
    for (final enc in [TextEnc.utf8, TextEnc.cp1256]) {
      final (bytes, names) = writeDbf(['الاسم', 'رقم'], [
        {'الاسم': 'أحمد', 'رقم': 3},
        {'الاسم': null, 'رقم': 4.5},
      ], enc: enc);
      final t = readDbf(bytes, enc: enc);
      expect(t.records.length, 2);
      expect(t.records[0][names['الاسم']], 'أحمد');
      expect(t.records[1][names['رقم']], 4.5);
    }
  });

  test('Shapefile ذهاب وعودة + مساحة', () {
    final files = writeShapefile(_parcel());
    // نوعين أشكال → shapefile لكل نوع
    expect(files.where((f) => f.name.endsWith('.shp')).length, 2);
    final polyFiles = {
      for (final f in files.where((f) => f.name.startsWith('test_polygons'))) f.name.split('.').last: f.bytes
    };
    final back = readShapefile('p', polyFiles);
    expect(back.crs.id, 'utm36n');
    expect(back.features.length, 1);
    expect(back.features.first.attrs['الاسم'], 'قطعة ١');
    final m = Measurer(back.crs).of(back.features.first);
    expect(m.area, closeTo(10000, 1e-6));
    expect(m.perimeter, closeTo(400, 1e-6));
  });

  test('تحويل WGS84 → UTM 36', () {
    final r = CrsTransformer(Crs.wgs84, Crs.utm36).apply(const Coord(31.2357, 30.0444));
    expect(r.x, closeTo(329899.64, 0.5));
    expect(r.y, closeTo(3325016.74, 0.5));
  });

  test('الحزام الأحمر (معاملات الإسقاط)', () {
    final r = CrsTransformer(Crs.wgs84, Crs.egRed).apply(const Coord(31.2357, 30.0444));
    // القيمة المرجعية من PROJ بنفس المعاملات
    expect(r.x, closeTo(637570.51, 2));
    expect(r.y, closeTo(814926.68, 2));
  });

  test('KML ذهاب وعودة', () {
    final kml = writeKml(_parcel());
    final back = readKml('k', utf8.encode(kml));
    expect(back.features.length, 2);
    expect(back.crs.id, 'wgs84');
    final poly = back.features.firstWhere((f) => f.type == GeomType.polygon);
    expect(poly.attrs['الاسم'], 'قطعة ١');
    final m = Measurer(back.crs, sample: poly.parts.first.first).of(poly);
    expect(m.area, closeTo(10000, 1)); // فرق بسيط من التحويل
  });

  test('KMZ', () {
    final back = readKmz('z', writeKmz(_parcel()));
    expect(back.features.length, 2);
  });

  test('GeoJSON', () {
    final back = readGeoJson('g', utf8.encode(writeGeoJson(_parcel())));
    expect(back.features.length, 2);
  });

  test('DXF', () {
    final back = readDxf('d', writeDxf(_parcel(), labelField: 'الاسم'), crs: Crs.utm36);
    expect(back.features.where((f) => f.type == GeomType.polygon).length, 1);
    // الأرقام الهندي بتتحول لإنجليزي في DXF
    expect(back.features.where((f) => f.attrs['text'] == 'قطعة 1').length, 1);
  });

  test('Excel ذهاب وعودة', () {
    final bytes = writeExcel(_parcel());
    final tables = readExcel('e', bytes);
    expect(tables.length, 1); // شيتات الملخص بتتجاهل
    final t = tables.first;
    expect(isOwnExport(t), isTrue);
    final m = guessMapping(t);
    expect(m.typeCol, isNotNull);
    final back = tableToLayer(t, m..crs = Crs.utm36);
    expect(back.features.length, 2);
    expect(back.features.where((f) => f.type == GeomType.polygon).length, 1);
  });

  test('CSV نقاط بالدرجات والدقائق', () {
    const csv = 'name,lat,lon\nA,30 02 39.8 N,31 14 08.5 E\nB,30.05,31.24\n';
    final t = readCsv('c', utf8.encode(csv));
    final m = guessMapping(t);
    final l = tableToLayer(t, m);
    expect(l.features.length, 2);
    expect(l.crs.id, 'wgs84');
    expect(l.features.first.parts.first.first.y, closeTo(30.0444, 1e-3));
  });

  test('loadFiles من zip shapefile', () {
    final out = packOutputs(writeShapefile(_parcel()), 'z');
    final res = loadFiles([InFile(out.name, out.bytes)]);
    expect(res.layers.length, 2);
  });

  test('فدان/قيراط/سهم', () {
    expect(feddanText(sqmPerFeddan), '1 ف  0 ط  0.0 س');
    expect(feddanText(sqmPerFeddan + sqmPerQirat * 3), '1 ف  3 ط  0.0 س');
  });
}
