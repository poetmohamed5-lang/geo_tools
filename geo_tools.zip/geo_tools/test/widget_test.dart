import 'package:flutter_test/flutter_test.dart';
import 'package:geo_tools/main.dart';

void main() {
  testWidgets('الشاشة الرئيسية بتفتح', (tester) async {
    await tester.pumpWidget(const GeoToolsApp());
    await tester.pumpAndSettle();
    expect(find.text('محوّل الملفات'), findsOneWidget);
    expect(find.text('سكانر المستندات → PDF'), findsOneWidget);
  });
}
